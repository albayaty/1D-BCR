# 1D-BCR
(1D BarCode Reader)

GNU GPL v3

==========================

By: Ali Al-Bayaty

Fulbright Scholar, MSEE '14

==========================
		Source Files
==========================
