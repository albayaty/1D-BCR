/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

// Histogram2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Histogram2.h"
#include "Histogram2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistogram2Dlg dialog

CHistogram2Dlg::CHistogram2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHistogram2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHistogram2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHistogram2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHistogram2Dlg)
	DDX_Control(pDX, IDC_ADMINCTRL1, m_ImgAdmin1);
	DDX_Control(pDX, IDC_EDITCTRL1, m_ImgEdit1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHistogram2Dlg, CDialog)
	//{{AFX_MSG_MAP(CHistogram2Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_BN_CLICKED(IDC_HISTO, OnHisto)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistogram2Dlg message handlers

BOOL CHistogram2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHistogram2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHistogram2Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHistogram2Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHistogram2Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	OnOK();	
}

void CHistogram2Dlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	CClientDC dc(this);
	
	//To Clear the Dialog Region...
	/*rgb=dc.GetPixel(3,3);
	for(i=16 ; i<316 ;i++)       //Threshold...
	{
		for(j=250 ; j<450 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}

	for(i=350 ; i<650 ;i++)      //Difference...
	{
		for(j=17 ; j<217 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}
	
	for(i=340 ; i<660 ;i++)      //Average...
	{
		for(j=240 ; j<460 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}*/	
	m_ImgEdit1.ClearDisplay();
	this->Invalidate(TRUE);

	m_ImgAdmin1.SetImage("");
	m_ImgAdmin1.SetDialogTitle("Select an Image...");
	m_ImgAdmin1.SetCancelError(FALSE);
	
	m_ImgAdmin1.SetFilter("All Image Files (*.bmp;*.jpg)|*.bmp; *.jpg|Bitmap Files    (*.bmp)|*.bmp|JPEG Files      (*.jpg)|*.jpg|All Files           (*.*)|*.*|");
	m_ImgAdmin1.SetFilterIndex(1);

	VARIANT vhWnd; V_VT(&vhWnd) =  VT_I4;
    V_I4(&vhWnd) = (long)m_hWnd;
	m_ImgAdmin1.ShowFileDialog(0,vhWnd);

	if(m_ImgAdmin1.GetImage() == "")
		return ;

	m_ImgEdit1.SetImage(m_ImgAdmin1.GetImage());

	VARIANT evt; V_VT(&evt) = VT_ERROR;
	m_ImgEdit1.FitTo(0,evt);

	m_ImgEdit1.Display();

	/*
	All Image Files (*.bmp;*.jpg)
	Bitmap Files    (*.bmp)
	JPEG Files      (*.jpg)
	All Files       (*.*)
	*/
}


void CHistogram2Dlg::OnTest() 
{
	// TODO: Add your control notification handler code here

	CClientDC dc(this);
	int i,j,J,shift1,shift2,shift3;
	COLORREF rgb2;
	//long hieght,width;
	//hieght=m_ImgEdit1.GetImageScaleHeight();
	//width=m_ImgEdit1.GetImageScaleWidth();

	//this->Invalidate(TRUE);
	//this->ShowWindow(SW_SHOWMAXIMIZED);
	
	//To Stretch the Image...
	for(i=17 ; i<209  ;i++)              //hieght...
	{
		shift1=0;
		shift2=1;
		shift3=2;
		for(j=16 ; j<283  ; j++)         //width...
		{
			J=j-15;

			rgb=dc.GetPixel(j,i);
			dc.SetPixelV(J+shift1,i+198,RGB(rgb,rgb,rgb));

			rgb1=dc.GetPixel(j+1,i);
			rgb2 = rgb + (rgb1-rgb)/2;
			dc.SetPixelV(J+shift2,i+198,RGB(rgb2,rgb2,rgb2));
			dc.SetPixelV(J+shift3,i+198,RGB(rgb2,rgb2,rgb2));

			shift1 +=2;
			shift2 +=2;
			shift3 +=2;
		}
	}
}

void CHistogram2Dlg::OnHisto() 
{
	// TODO: Add your control notification handler code here

	//MessageBox("done1...","done...",MB_OK);
	CClientDC dc(this);
	int i,j,I,J,k,N,Nk[16],swap_int,r[16];
	float Pr[16],S[16],r2[16];
	RECT m_rect={10,10,50,50};
	CRect m_crect;
	CBrush m_brush;
		
	FILE *fptr1/*,*fptr2,*fptr3,*fptr4,*fptr5,*fptr6*/;
	fptr1=fopen("c:\\BarCode\\histogram.txt","w");
/*	fptr2=fopen("c:\\histogram2.txt","w");
	fptr3=fopen("c:\\test0.5.txt","w");
	fptr4=fopen("c:\\test0.6.txt","w");
	fptr5=fopen("c:\\test0.7.txt","w");
	fptr6=fopen("c:\\_result_.txt","w");
*/			
	
	//MessageBox("done2...","done...",MB_OK);

	//Clearing all the varaibles...
	for(k=0 ; k<16 ; k++)
	{
		Nk[k]   = 0  ;
		Pr[k]   = 0.0;
		S[k]    = 0.0;
	}

	r[0 ] = 0  ;  r2[0]=0.000000;
	r[1 ] = 32 ;  //r2[1]=0.015625;
	r[2 ] = 48 ;  //r2[2]=0.010416;
	r[3 ] = 64 ;  //r2[3]=0.007874;
	r[4 ] = 80 ;  //r2[4]=0.006250;
	r[5 ] = 96 ;  //r2[5]=0.005208;
	r[6 ] = 112;  //r2[6]=0.004464;
	r[7 ] = 128;  //r2[7]=0.003921;
	r[8 ] = 144;
	r[9 ] = 160;
	r[10] = 176;
	r[11] = 192;
	r[12] = 208;
	r[13] = 224;
	r[14] = 240;
	r[15] = 255;

	for(i=1 ; i<16 ; i++)
		r2[i] = 1 / (float)r[i];

	swap_int = 0;
	
	fprintf(fptr1,"Clearing all the Variables...\n ");
	fprintf(fptr1,"\n r()\t      1/r() \t   Nk         Pr \t     S ");
	fprintf(fptr1,"\n----\t     -------\t  ----       ----\t    ---");
//	fprintf(fptr1,"\n %d \t    %f   \t   %d      %f \t  %f");

	for(i=0 ; i<16 ; i++)
		fprintf(fptr1,"\n %d \t    %f   \t   %d      %f \t  %f",r[i],r2[i],Nk[i],Pr[i],S[i]);
	
	//Find the Width and Height...
	for(I=99 ; I<210 ; I++)
	{
		for(J=283 ; J>16 ; J--)
		{
			rgb=dc.GetPixel(J,I);
			rgb1=dc.GetPixel(J-1,I);
			if(rgb-rgb1)
			{
				width=J;
				goto okw;
			}
			dc.SetPixelV(J,I,RGB(255,0,0));
		}
	}
	

okw:width -= 16;

	for(I=99 ; I<284 ; I++)
	{
		for(J=209 ; J>17 ; J--)
		{
			rgb=dc.GetPixel(I,J);
			rgb1=dc.GetPixel(I,J-1);
			if(rgb-rgb1)
			{
				hieght=J;
				goto okh;
			}
			dc.SetPixelV(I,J,RGB(255,0,0));
		}
	}

okh:hieght -= 17;

	
	//To Draw the Re-Quantization...
	for(i=17 ; i<hieght+17 ; i++)
	{
		//I=i-17;
		for(j=16 ; j<width+16 ; j++)
		{
			//J=j-16;
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(255,0,0));			
			
			if(rgb <= RGB(16,16,16))
			{
				rgb=0; Nk[0]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(32,32,32))
			{
				rgb=32;	Nk[1]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(48,48,48))
			{
				rgb=48;	Nk[2]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(64,64,64))
			{
				rgb=64;	Nk[3]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(80,80,80))
			{
				rgb=80;	Nk[4]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(96,96,96))
			{
				rgb=96;	Nk[5]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(112,112,112))
			{
				rgb=112; Nk[6]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(128,128,128))
			{
				rgb=128; Nk[7]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(144,144,144))
			{
				rgb=144; Nk[8]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(160,160,160))
			{
				rgb=160; Nk[9]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(176,176,176))
			{
				rgb=176; Nk[10]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(192,192,192))
			{
				rgb=192; Nk[11]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(208,208,208))
			{
				rgb=208; Nk[12]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(224,224,224))
			{
				rgb=224; Nk[13]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}
			
			if(rgb <= RGB(240,240,240))
			{
				rgb=240; Nk[14]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

			if(rgb <= RGB(255,255,255))
			{
				rgb=255; Nk[15]++;
				dc.SetPixelV(j+334,i,RGB(rgb,rgb,rgb));
				goto okq;
			}

okq:        J=j-16;//To Continue...
		}
	}


	N=width * hieght;  // # of pixels...	

	for(k=0 ; k<16 ; k++)
		Pr[k]=(float)Nk[k] / (float)N;

	for(i= 0 ; i<16 ; i++)
	{
		for(j=0 ; j<(i+1) ; j++)
			S[i] +=  Pr[j];
	}

	for(i=0 ; i<16 ; i++)
		S[i] *= 255.0;

	fprintf(fptr1,"\n\n\nThe Variables are: (after Histogram)\n");
	//fprintf(fptr1,"\n\n");
	for(i=0 ; i<16 ; i++)
		fprintf(fptr1,"\n %d \t    %f   \t   %d      %f \t  %f",r[i],r2[i],Nk[i],Pr[i],S[i]);


	//To Draw the Histogram...
	for(i=0 ; i<16 ; i++)
		Nk[i] = (int)S[i];

	for(i=17 ; i<hieght+17 ; i++)
	{
		for(j=350 ; j<width+350 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(255,0,0));
			

			if(rgb == RGB(  0,  0,  0))
			{
				rgb=Nk[0]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB( 32, 32, 32))
			{
				rgb=Nk[1]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB( 48, 48, 48))
			{
				rgb=Nk[2]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB( 64, 64, 64))
			{
				rgb=Nk[3]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB( 80, 80, 80))
			{
				rgb=Nk[4]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB( 96, 96, 96))
			{
				rgb=Nk[5]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(112,112,112))
			{
				rgb=Nk[6]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(128,128,128))
			{
				rgb=Nk[7]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(144,144,144))
			{
				rgb=Nk[8]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(160,160,160))
			{
				rgb=Nk[9]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(176,176,176))
			{
				rgb=Nk[10]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(192,192,192))
			{
				rgb=Nk[11]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(208,208,208))
			{
				rgb=Nk[12]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(224,224,224))
			{
				rgb=Nk[13]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(240,240,240))
			{
				rgb=Nk[14]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

			if(rgb == RGB(255,255,255))
			{
				rgb=Nk[15]; dc.SetPixelV(j-334,i+198,RGB(rgb,rgb,rgb));
				goto okn;
			}

okn:        J=j-16; //To Continue...
		}
	}	
	

	//To Draw the Threshold...
	for(i=17 ; i<hieght+17 ; i++)
	{
		for(j=350 ; j<width+350 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i+198,RGB(255,0,0));

			if(rgb < RGB(112,112,112))
				rgb=0;
			else
				rgb=255;

			dc.SetPixelV(j,i+198,RGB(rgb,rgb,rgb));
		}
	}


	fprintf(fptr1,"\n");
	fprintf(fptr1,"\n The # of Pixels = %d ",N);

	fcloseall();
	MessageBox("done...","DONE  !!!",MB_OK);
}
