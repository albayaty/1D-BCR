/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

// Histogram2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Histogram2.h"
#include "Histogram2Dlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistogram2Dlg dialog

CHistogram2Dlg::CHistogram2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHistogram2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHistogram2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHistogram2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHistogram2Dlg)
	DDX_Control(pDX, IDC_ADMINCTRL1, m_ImgAdmin1);
	DDX_Control(pDX, IDC_EDITCTRL1, m_ImgEdit1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHistogram2Dlg, CDialog)
	//{{AFX_MSG_MAP(CHistogram2Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_BN_CLICKED(IDC_HISTO, OnHisto)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistogram2Dlg message handlers

BOOL CHistogram2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHistogram2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHistogram2Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHistogram2Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHistogram2Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	OnOK();	
}

void CHistogram2Dlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	CClientDC dc(this);
	
	//To Clear the Dialog Region...
	/*rgb=dc.GetPixel(3,3);
	for(i=16 ; i<316 ;i++)       //Threshold...
	{
		for(j=250 ; j<450 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}

	for(i=350 ; i<650 ;i++)      //Difference...
	{
		for(j=17 ; j<217 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}
	
	for(i=340 ; i<660 ;i++)      //Average...
	{
		for(j=240 ; j<460 ; j++)
			dc.SetPixelV(i,j,RGB(rgb,rgb,rgb));
	}*/	
	m_ImgEdit1.ClearDisplay();
	this->Invalidate(TRUE);

	m_ImgAdmin1.SetImage("");
	m_ImgAdmin1.SetDialogTitle("Select an Image...");
	m_ImgAdmin1.SetCancelError(FALSE);
	
	m_ImgAdmin1.SetFilter("All Image Files (*.bmp;*.jpg)|*.bmp; *.jpg|Bitmap Files    (*.bmp)|*.bmp|JPEG Files      (*.jpg)|*.jpg|All Files           (*.*)|*.*|");
	m_ImgAdmin1.SetFilterIndex(1);

	VARIANT vhWnd; V_VT(&vhWnd) =  VT_I4;
    V_I4(&vhWnd) = (long)m_hWnd;
	m_ImgAdmin1.ShowFileDialog(0,vhWnd);

	if(m_ImgAdmin1.GetImage() == "")
		return ;

	m_ImgEdit1.SetImage(m_ImgAdmin1.GetImage());

	VARIANT evt; V_VT(&evt) = VT_ERROR;
	m_ImgEdit1.FitTo(0,evt);

	m_ImgEdit1.Display();

	/*
	All Image Files (*.bmp;*.jpg)
	Bitmap Files    (*.bmp)
	JPEG Files      (*.jpg)
	All Files       (*.*)
	*/
}


void CHistogram2Dlg::OnTest() 
{
	// TODO: Add your control notification handler code here

	CClientDC dc(this);
	int i,j,J,shift1,shift2,shift3;
	COLORREF rgb2;
	//long hieght,width;
	//hieght=m_ImgEdit1.GetImageScaleHeight();
	//width=m_ImgEdit1.GetImageScaleWidth();

	//this->Invalidate(TRUE);
	//this->ShowWindow(SW_SHOWMAXIMIZED);
	
	//To Stretch the Image...
	for(i=17 ; i<209  ;i++)              //hieght...
	{
		shift1=0;
		shift2=1;
		shift3=2;
		for(j=16 ; j<283  ; j++)         //width...
		{
			J=j-15;

			rgb=dc.GetPixel(j,i);
			dc.SetPixelV(J+shift1,i+198,RGB(rgb,rgb,rgb));

			rgb1=dc.GetPixel(j+1,i);
			rgb2 = rgb + (rgb1-rgb)/2;
			dc.SetPixelV(J+shift2,i+198,RGB(rgb2,rgb2,rgb2));
			dc.SetPixelV(J+shift3,i+198,RGB(rgb2,rgb2,rgb2));

			shift1 +=2;
			shift2 +=2;
			shift3 +=2;
		}
	}
}

void CHistogram2Dlg::OnHisto() 
{
	// TODO: Add your control notification handler code here

	//MessageBox("done1...","done...",MB_OK);
	CClientDC dc(this);
	int i,j,I,J,k/*,N*/,check1,check2,check3,x1,x2,/*x3,*/y1,y2,/*y3,*/BAR,SPACE,
		barcodex1,barcodex2,barcodey1,barcodey2/*,shift1,shift2,shift3*/;
	//char barcodesymbol;
	COLORREF /*PixelColor[300][200]*/Barcode[600][200],barcode[35];
	RECT m_rect={10,10,50,50}/*,m_rect2={11,11,51,51}*/;
	CRect m_crect/*1,m_crect2*/;
	CBrush m_brush/*1,m_brush2*/;
	char bar_space;
	
	FILE *fptr1,*fptr2,*fptr3,*fptr4,*fptr5,*fptr6;
	fptr1=fopen("c:\\BarCode\\test0.3.txt","w");
	fptr2=fopen("c:\\BarCode\\test0.4.txt","w");
	fptr3=fopen("c:\\BarCode\\test0.5.txt","w");
	fptr4=fopen("c:\\BarCode\\test0.6.txt","w");
	fptr5=fopen("c:\\BarCode\\test0.7.txt","w");
	//fptr6=fopen("c:\\BarCode\\_result_.txt","w");
			
	/*struct tagApper{
		int mag;
		int max;
		}Apper[256];

	struct tagPixel{
		COLORREF color;
		int LocAtApper;
		}PixelInfo[300][200];*/
		
	for(i=0 ; i<600 ; i++)
	{
		for(k=0 ; k<200 ; k++)
			Barcode[i][k]=0;
	}

	for(i=0 ; i<35 ; i++)
		barcode[i]=0;

	//MessageBox("done2...","done...",MB_OK);
	//Find the Width and Hieght...
	for(i=99 ; i<210 ; i++)
	{
		for(j=283 ; j>16 ; j--)
		{
			rgb=dc.GetPixel(j,i);
			rgb1=dc.GetPixel(j-1,i);
			if(rgb-rgb1)
			{
				width=j;
				goto okw;
			}
			dc.SetPixelV(j,i,RGB(255,0,0));
		}
	}

okw:width -= 16;

	for(i=99 ; i<284 ; i++)
	{
		for(j=209 ; j>17 ; j--)
		{
			rgb=dc.GetPixel(i,j);
			rgb1=dc.GetPixel(i,j-1);
			if(rgb-rgb1)
			{
				hieght=j;
				goto okh;
			}
			dc.SetPixelV(i,j,RGB(255,0,0));
		}
	}

okh:hieght -= 17;

	for(i=17 ; i<hieght+17 ; i++)
	{
		//I=i-17;
		for(j=16 ; j<width+16 ; j++)
		{
			J=j-16;
			rgb=dc.GetPixel(j,i);
			//PixelColor[J][I]=rgb;
			//dc.SetPixelV(i,j,RGB(255,0,0));

			//To Draw the Threshold...
			if(rgb >= 0x007f7f7f)
			{
				rgb1=255;
				dc.SetPixelV(j+334,i,RGB(255,255,255));
			}
			else
			{
				rgb1=0;
				dc.SetPixelV(j+334,i,RGB(0,0,0));
			}

			//To Draw the Difference...
			rgb1=abs(rgb1-rgb);			
			dc.SetPixelV(j,i+198,RGB(rgb1,rgb1,rgb1));
			
			//To Draw the Averaging...
			rgb1=(rgb+rgb1)/2;			
			if(rgb1 >= 0x007f7f7f)
				dc.SetPixelV(j+334,i+198,RGB(255,0,0));
			else
				dc.SetPixelV(j+334,i+198,RGB(rgb1,rgb1,rgb1));
		}
	}

	//MessageBox("done3...","done...",MB_OK);
	
	//N=(int)(width*hieght);  // # of pixels...

	
	//To Draw the Clipping Region...(Blue Rect)
	check1=350+(width/5);
	for(i=215 ; i<hieght+215 ; i++)
	{
		for(j=350 ; j<check1 ; j++)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb == RGB(255,0,0))
			{				
				m_rect.left=j;
				x1=j+2;
				m_rect.top=i;
				y1=i+2;
				goto NEXT1;
			}
		}
	}
NEXT1:

	check2=(width+349)-(width/5);
	for(i=hieght+214 ; i>215 ; i--)
	{		
		for(j=width+349 ; j>check2 ; j--)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb == RGB(255,0,0))
			{				
				m_rect.right=j;
				x2=j-2;
				m_rect.bottom=i;
				y2=i-2;
				goto FINISH1;
			}
		}
	}
FINISH1:
	
	m_brush.CreateSolidBrush(RGB(0,0,255));
	m_crect.CopyRect(&m_rect);
	dc.FrameRect(&m_crect,&m_brush);
	
	m_brush.Detach();   //The Important One...



	//To Find the Barcode Area... (Green Rect)
	check1=y1+((y2-y1)/4);
	for(j=x1 ; j<x2 ; j++)
	{
		for(i=y1 ; i<check1 ; i++)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb != 0x000000ff)         //RGB(255,0,0) 
			{				
				m_rect.left=j-3;
				barcodex1=j-2;
				m_rect.top=i-3;
				barcodey1=i-2;
				goto NEXT2;
			}
		}
	}
NEXT2:
	
	check2=y2-((y2-y1)/4);
	for(j=x2 ; j>x1 ; j--)
	{		
		for(i=y2 ; i>check2 ; i--)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb != 0x000000ff)
			{				
				m_rect.right=j+3;
				barcodex2=j+2;
				m_rect.bottom=i+3;
				barcodey2=i+2;
				goto FINISH2;
			}
		}
	}
FINISH2:
	
	m_brush.CreateSolidBrush(RGB(0,255,0));
	m_crect.CopyRect(&m_rect);
	dc.FrameRect(&m_crect,&m_brush);
	

	//To Draw the Stretched Barcode...
/*	I=415;
	for(i=barcodey1 ; i<barcodey2  ;i++)              //hieght...
	{
		shift1=0;
		shift2=1;
		shift3=2;
		J=0;
		for(j=barcodex1 ; j<barcodex2  ; j++)         //width...
		{
			rgb=dc.GetPixel(j,i);
			//if(rgb < RGB(128,128,128)) rgb=0;
			//else rgb=255;
			dc.SetPixelV(J+shift1,I,RGB(rgb,rgb,rgb));
			
			rgb1=dc.GetPixel(j+1,i);
			//if(rgb1 < RGB(128,128,128)) rgb1=0;
			//else rgb1=255;
			rgb1 = rgb + (rgb1-rgb)/2;
			dc.SetPixelV(J+shift2,I,RGB(rgb1,rgb1,rgb1));
			dc.SetPixelV(J+shift3,I,RGB(rgb1,rgb1,rgb1));

			shift1 +=2;
			shift2 +=2;
			shift3 +=2;
			J++;			
		}
		I++;
		check1=J*3;
		check2=I;
	}
*/	
	I=415;
	for(i=barcodey1 ; i<barcodey2  ;i++)              //hieght...
	{
		J=0;
		for(j=barcodex1 ; j<barcodex2  ; j++)         //width...
		{
			rgb=dc.GetPixel(j,i);
			dc.SetPixelV(J,I,RGB(rgb,rgb,rgb));
			
			J++;			
		}
		I++;
		check1=J;
		check2=I;
	}

	//To Threshold the Stretched Barcode...
	for(i=415 ; i<check2 ; i++)      //hieght...
	{
		for(j=0 ; j<check1 ; j++)            //width...
		{
			rgb  = dc.GetPixel(j,i);
			if(rgb < RGB(128,128,128)) rgb=0;
			else rgb=255;

			dc.SetPixelV(j,i,RGB(rgb,rgb,rgb));
		}
	}			


	//To Enhanced the Stretched Barcode...
	check3 = (int)(415 + ((check2-415)/2));

	//The Upper...
	for(i=check3 ; i>415 ; i--)              //hieght...
	{
		for(j=0 ; j<check1 ; j++)            //width...
		{
			rgb  = dc.GetPixel(j,i);
			if(rgb < RGB(128,128,128)) rgb=0;
			else rgb=255;
/*
			rgb1 = dc.GetPixel(j,i-1);
			if(rgb1 < RGB(128,128,128)) rgb1=0;
			else rgb1=255;
	
			rgb2 = dc.GetPixel(j,i+2);
			if(rgb2 < RGB(128,128,128)) rgb2=0;
			else rgb2=255;
			
			rgb3 = dc.GetPixel(j+2,i+2);
			if(rgb3 < RGB(128,128,128)) rgb3=0;
			else rgb3=255;
*/
			if( rgb==0 )
				dc.SetPixelV(j,i-1,RGB(0,0,0));
			
			if( rgb==255 )
				dc.SetPixelV(j,i-1,RGB(255,255,255));
			
			//dc.SetPixelV(j,i,RGB(255,0,0));
		}
	}
		
	
	//The Lower...
	for(i=check3 ; i<check2 ; i++)           //hieght...
	{
		for(j=0 ; j<check1 ; j++)            //width...
		{
			rgb  = dc.GetPixel(j,i);
			if(rgb < RGB(128,128,128)) rgb=0;
			else rgb=255;

			if( rgb==0 )
				dc.SetPixelV(j,i+1,RGB(0,0,0));
			
			if( rgb==255 )
				dc.SetPixelV(j,i+1,RGB(255,255,255));					
			
			//dc.SetPixelV(j,i,RGB(255,0,0));
		}
	}
	
	//To Scan from Multiple Positions in the Stretched Barcode...
	for(i=3 ; i<8 ; i++)
	{
		check3 = (int)(415 + ((check2-415)*i*0.1)); 
		BAR=-1;
		SPACE=-1;
		I=0; //Counter how many digits store in the file...
		rgb1=0;
		//J=0;
		k=0;
		bar_space='!';
		for(j=0 ; j<check1 ; j++)            //width...
		{
			rgb=dc.GetPixel(j,check3);

			if(rgb <= RGB(127,127,127) && BAR >= 0)
			{
				BAR++;
				SPACE=0;
				//I=BAR;
				dc.SetPixelV(j,check3,RGB(0,0,255));
			}
		
			if(rgb > RGB(127,127,127) && SPACE == -1)
				BAR=0;
			
			if(rgb > RGB(127,127,127) && SPACE >= 0)
			{
				SPACE++;
				BAR=0;
				//J=SPACE;
				dc.SetPixelV(j,check3,RGB(255,0,0));
			}

			if(rgb < RGB(128,128,128))	rgb=0;			
		
			if(rgb >= RGB(128,128,128))	rgb=255;			
		
			if(rgb != rgb1)
			{
				if(i == 3) fprintf(fptr1,"\n %d %c",k,bar_space);
				if(i == 4) fprintf(fptr2,"\n %d %c",k,bar_space);
				if(i == 5) fprintf(fptr3,"\n %d %c",k,bar_space);
				if(i == 6) fprintf(fptr4,"\n %d %c",k,bar_space);
				if(i == 7) fprintf(fptr5,"\n %d %c",k,bar_space);
				I++;
			}
		
			if(BAR)
			{
				k=BAR;
				bar_space='b';
			}
			else
			{
				k=SPACE;
				bar_space='w';
			}

			rgb1=rgb;
			//dc.SetPixelV(j,check2,RGB(255,0,0));
		}
	}

	fcloseall();

	fptr1=fopen("c:\\BarCode\\test0.3.txt","r");
	fptr2=fopen("c:\\BarCode\\test0.4.txt","r");
	fptr3=fopen("c:\\BarCode\\test0.5.txt","r");
	fptr4=fopen("c:\\BarCode\\test0.6.txt","r");
	fptr5=fopen("c:\\BarCode\\test0.7.txt","r");
	fptr6=fopen("c:\\BarCode\\_result_.txt","w");

	
	for(i=0 ; i<I ; i++)
	{
		check2=0;

		fscanf(fptr1,"\n %d %c",&check1,&bar_space); check2  =check1;
		fscanf(fptr2,"\n %d %c",&check1,&bar_space); check2 +=check1;
		fscanf(fptr3,"\n %d %c",&check1,&bar_space); check2 +=check1;
		fscanf(fptr4,"\n %d %c",&check1,&bar_space); check2 +=check1;
		fscanf(fptr5,"\n %d %c",&check1,&bar_space); check2 +=check1;

		check2 =(int)(check2 / 5);
		fprintf(fptr6,"\n %d %c",check2,bar_space);
	}


	
	//To Draw the Enhanced BARCODE...from the Stretched One!!!
/*	for(j=0 ; j<check1 ;j++)
	{
		BAR=0;
		SPACE=0;
		for(i=415 ; i<check2 ;i++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if((rgb > 0x00808078))
				SPACE++;
			else 			
				BAR++;			
		}
		
		if(BAR > SPACE)
			rgb=0;
		else
			rgb=255;

		for(i=430 ; i<check2 ;i++)
			dc.SetPixelV(j,i,RGB(rgb,rgb,rgb));		
	}

	//To Draw the "amjb here..."...
	x3 = x1 + ((x2-x1)/3);
	y3 = y1 + ((y2-y1)/2);	
	dc.ExtTextOut(x3,y3,ETO_CLIPPED,m_crect,"amjb here...",12,NULL);
*/
	fcloseall();
	DecodeBarcode(I);
	MessageBox("done...","DONE",MB_OK);
}


void CHistogram2Dlg::DecodeBarcode(int counter)
{
	int i,j,cint;
	float BarcodeData[59],BarcodeBlock[12],cfloat;
	char bar_space;
	FILE *fptr1,*fptr2;
	
	fptr1=fopen("c:\\BarCode\\_result_.txt","r");
	fptr2=fopen("c:\\BarCode\\Barcode.txt","w");

	
	//Store the _result_.TXT in the Array...
	j=0;
	for(i=0 ; i<counter ; i++)
	{
		fscanf(fptr1,"\n %d %c",&cint,&bar_space);
		if(cint > 0)
		{
			BarcodeData[j] = (float)cint; j++;
		}
	}

	fprintf(fptr2,"\n");
	//Test the BarcodeData[]...
/*	for(i=0 ; i<59 ; i++)
		fprintf(fptr2," BarcodeData[%d]= %f\n",i,BarcodeData[i]);
*/

	//To get the Divider for all in the BarcodeData[]...
	cfloat =(float)( (BarcodeData[0 ] + BarcodeData[1 ] + BarcodeData[2 ] 
		  + BarcodeData[27]+ BarcodeData[28] + BarcodeData[29] + BarcodeData[30] + BarcodeData[31]
		  + BarcodeData[56] + BarcodeData[57] + BarcodeData[58]) / 11.0 );

	//if(check > 1)
	//{
		for(i=0 ; i<59 ; i++)
		{
			BarcodeData[i] /= cfloat;

			if(BarcodeData[i] == 0.0)
				BarcodeData[i]=1.0;

			BarcodeData[i] += 0.5;
			BarcodeData[i] = (float)(floor(BarcodeData[i]));

			//fprintf(fptr2,"\n BarcodeData[%d]= %f",i,BarcodeData[i]);
		}
	//}

	//fprintf(fptr2,"\n ");
	//Store the BarcodeData[] in the BarcodeBlock[]...
	//The Left-Hand Side Barcode...
	j=0;
	for(i=3 ; i<27 ; i+=4)
	{
		BarcodeData[i  ] *= 2000.0;
		BarcodeData[i+1] *= 200.0;
		BarcodeData[i+2] *= 20.0;
		BarcodeData[i+3] *= 2.0;
	
		BarcodeBlock[j] = BarcodeData[i  ] + BarcodeData[i+1] + 
			              BarcodeData[i+2] + BarcodeData[i+3];
		
		fprintf(fptr2," %d\n",(int)BarcodeBlock[j]);
		j++;
	}

	//The Right-Hand Side Barcode...
	j=6;
	for(i=32 ; i<56 ; i+=4)
	{
		BarcodeData[i  ] *= 2000.0;
		BarcodeData[i+1] *= 200.0;
		BarcodeData[i+2] *= 20.0;
		BarcodeData[i+3] *= 2.0;
	
		BarcodeBlock[j] = BarcodeData[i  ] + BarcodeData[i+1] + 
			              BarcodeData[i+2] + BarcodeData[i+3];
		
		fprintf(fptr2," %d\n",(int)BarcodeBlock[j]);
		j++;
	}	

	fcloseall();

	BarcodeLookupTable();
}

void CHistogram2Dlg::BarcodeLookupTable()
{
	//BOOL BARCODETYPE[12];
	CClientDC dc(this);
	int i,j,check,barcode[13];
	CString Direction,BARCODE[13],BarcodeType,BARCODETYPE[6];
	FILE *fptr1,*fptr2;
		
	fptr1=fopen("c:\\BarCode\\Barcode.txt","r");
	fptr2=fopen("c:\\BarCode\\test.txt","w");

	Direction="Left";
	j=0;

	fprintf(fptr2,"\n");
	//Clearing the BARCODE[]...
	for(i=0 ; i<13 ;i++)
	{
		BARCODE[i]="?";
		fprintf(fptr2," BARCODE[%d]= %s\n",i,BARCODE[i]);
	}

	//L-R Encoding...	
	for(i=0 ; i<12 ; i++)
	{
		j=i+1;
		fscanf(fptr1," %d\n",&check);
		fprintf(fptr2," %d\n",check);
		
		//Left-Hand Encoding...
		if( check > 7322 && Direction == "Left")                 { barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="1";}
		if( check > 6332 && check <= 7322 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="0";}
		if( check > 6233 && check <= 6332 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="1";}
		if( check > 5423 && check <= 6233 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="0";}
		if( check > 4532 && check <= 5423 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="1";}
		if( check > 4433 && check <= 4532 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="0";}
		if( check > 4343 && check <= 4433 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="1";}
		if( check > 4253 && check <= 4343 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="1";}
		if( check > 4235 && check <= 4253 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="0";}
		if( check > 3524 && check <= 4235 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="1";}
		if( check > 2732 && check <= 3524 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="0";}
		if( check > 2633 && check <= 2732 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="1";}
		if( check > 2543 && check <= 2633 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="0";}
		if( check > 2453 && check <= 2543 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="0";}
		if( check > 2435 && check <= 2453 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="1";}
		if( check > 2354 && check <= 2435 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="0";}
		if( check > 2273 && check <= 2354 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="1";}
		if( check > 2255 && check <= 2273 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="0";}
		if( check > 2237 && check <= 2255 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="1";}
		if( check <= 2237 && Direction == "Left")                { barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="0";}


		//Right-Hand Encoding...
		if( check > 6323 && Direction == "Right")                  { barcode[j]=0; BARCODE[j]="0";}
		if( check > 5333 && check <= 6323 && Direction == "Right") { barcode[j]=9; BARCODE[j]="9";}
		if( check > 4343 && check <= 5333 && Direction == "Right") { barcode[j]=1; BARCODE[j]="1";}
		if( check > 3533 && check <= 4343 && Direction == "Right") { barcode[j]=2; BARCODE[j]="2";}
		if( check > 2723 && check <= 3533 && Direction == "Right") { barcode[j]=3; BARCODE[j]="3";}
		if( check > 2543 && check <= 2723 && Direction == "Right") { barcode[j]=7; BARCODE[j]="7";}
		if( check > 2444 && check <= 2543 && Direction == "Right") { barcode[j]=5; BARCODE[j]="5";}
		if( check > 2345 && check <= 2444 && Direction == "Right") { barcode[j]=8; BARCODE[j]="8";}
		if( check > 2246 && check <= 2345 && Direction == "Right") { barcode[j]=4; BARCODE[j]="4";}
		if( check <= 2246 && Direction == "Right")                 { barcode[j]=6; BARCODE[j]="6";}
		
		if(i >= 6)  Direction="Right";
	}
	
	//Find the System Digit...
	BarcodeType=BARCODETYPE[0]+BARCODETYPE[1]+BARCODETYPE[2]+
		        BARCODETYPE[3]+BARCODETYPE[4]+BARCODETYPE[5];

	fprintf(fptr2,"\n BarcodeType= %s",BarcodeType);

	if(BarcodeType == "000000") BARCODE[0]="0";
	if(BarcodeType == "001011") BARCODE[0]="1";
	if(BarcodeType == "001101") BARCODE[0]="2";
	if(BarcodeType == "001110") BARCODE[0]="3";
	if(BarcodeType == "010011") BARCODE[0]="4";
	if(BarcodeType == "011001") BARCODE[0]="5";
	if(BarcodeType == "011100") BARCODE[0]="6";
	if(BarcodeType == "010101") BARCODE[0]="7";
	if(BarcodeType == "010110") BARCODE[0]="8";
	if(BarcodeType == "011010") BARCODE[0]="9";

	fprintf(fptr2,"\n");
	//Printing the Result...
	fprintf(fptr2,"\n BARCODE[0]= %s",BARCODE[0]);
	for(i=1 ; i<13 ; i++)
	{
		j=i-1;
		if(i <= 6)
			fprintf(fptr2,"\n BARCODE[%d]= %s\tBARCODETYPE[%d]= %s",i,BARCODE[i],j,BARCODETYPE[j]);
		else
			fprintf(fptr2,"\n BARCODE[%d]= %s",i,BARCODE[i]);
	}

	BarcodeType=" "+BARCODE[0]+" "+BARCODE[1]+BARCODE[2]+BARCODE[3]+BARCODE[4]+BARCODE[5]+BARCODE[6]+
		        " "+BARCODE[7]+BARCODE[8]+BARCODE[9]+BARCODE[10]+BARCODE[11]+BARCODE[12]+" ";


	fprintf(fptr2,"\n BarcodeType= %s",BarcodeType);

	//To Draw the "amjb here..."...
/*	x3 = x1 + ((x2-x1)/3);
	y3 = y1 + ((y2-y1)/2);	*/
	//dc.ExtTextOut(25,450,ETO_CLIPPED,m_crect,BarcodeType,12,NULL);
	dc.TextOut(35,480,BarcodeType);

	fcloseall();
}

/*
	L-ODD & R:-

	if( > 6323)  0
	if( > 5333 && <= 6323)  9
	if( > 4343 && <= 5333)  1
	if( > 3533 && <= 4343)  2
	if( > 2723 && <= 3533)  3
	if( > 2543 && <= 2723)  7
	if( > 2444 && <= 2543)  5
	if( > 2345 && <= 2444)  8
	if( > 2246 && <= 2345)  4
	if( <= 2246)  6

    L-EVEN:-

	if( > 7232)  6
	if( > 5432 && <= 7232)  8
	if( > 4523 && <= 5432)  4
	if( > 4343 && <= 4523)  2
	if( > 4244 && <= 4343)  7
	if( > 3434 && <= 4244)  9
	if( > 2543 && <= 3434)  5
	if( > 2363 && <= 2543)  1
	if( > 2264 && <= 2363)  3
	if( <= 2264)  0
*/