/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

// Barcode1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Barcode1.h"
#include "Barcode1Dlg.h"
#include "math.h"
#include "comdef.h"
//#include "cputicker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBarcode1Dlg dialog

CBarcode1Dlg::CBarcode1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBarcode1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBarcode1Dlg)
	m_Step1 = _T("");
	m_Step2 = _T("");
	m_Step3 = _T("");
	Info = _T("");
	Block1 = _T("");
	Block2 = _T("");
	Block3 = _T("");
	Block4 = _T("");
	Block5 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBarcode1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBarcode1Dlg)
	DDX_Control(pDX, IDC_IMGEDITCTRL1, m_ImgEdit1);
	DDX_Control(pDX, IDC_IMGEDITCTRL2, m_ImgEdit2);
	DDX_Control(pDX, IDC_IMGADMINCTRL1, m_ImgAdmin1);
	DDX_Text(pDX, IDC_STEP1INFO, m_Step1);
	DDX_Text(pDX, IDC_STEP2INFO, m_Step2);
	DDX_Text(pDX, IDC_STEP3INFO, m_Step3);
	DDX_Control(pDX, IDC_MSCHART1, m_Chart1);
	DDX_Control(pDX, IDC_MSCHART2, m_Chart2);
	DDX_Control(pDX, IDC_MSCHART3, m_Chart3);
	DDX_Text(pDX, IDC_INFO, Info);
	DDX_Text(pDX, IDC_BLOCK1, Block1);
	DDX_Text(pDX, IDC_BLOCK2, Block2);
	DDX_Text(pDX, IDC_BLOCK3, Block3);
	DDX_Text(pDX, IDC_BLOCK4, Block4);
	DDX_Text(pDX, IDC_BLOCK5, Block5);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CBarcode1Dlg, CDialog)
	//{{AFX_MSG_MAP(CBarcode1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_LOADIMAGE, OnLoadImage)
	ON_BN_CLICKED(IDC_CONVERT2GS, OnConvert2GS)
	ON_BN_CLICKED(IDC_AMJBFILTER1, OnamjbFilter1)
	ON_BN_CLICKED(IDC_AMJBFILTER2, OnamjbFilter2)
	ON_BN_CLICKED(IDC_BCDECODE, OnBCDecode)
	ON_BN_CLICKED(IDC_DRAW, OnDraw)
	ON_BN_CLICKED(IDC_EXIT, OnExit)	
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
//	ON_BN_CLICKED(IDC_ABC, OnAbc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBarcode1Dlg message handlers

BOOL CBarcode1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here	

	fptr3=fopen("c:\\barcode\\status.txt","r");
	fscanf(fptr3,"%s",status);

	if( ! Tick01.IsSupported() )
	{
		MessageBox("Error In Tick's Timer !","Error ...",MB_OK);
		OnExit();
	}

	GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);
	GetDlgItem(IDC_DRAW)->EnableWindow(FALSE);

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);
	//GetDlgItem(IDC_EXIT)->EnableWindow(FALSE);


	ClearSteps();	

	ShowInfo(0);

	CheckInfo = -1 ;
	NewButton = false ;

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_LOADIMAGE);
	GotoDlgCtrl(GetFocus);
	
	//
	////
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CBarcode1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBarcode1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBarcode1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CBarcode1Dlg::ShowInfo(int WhichOperation)
{
	//Initialization ...
	if(WhichOperation == 0)
	{
		Block1 = "No operation initialized..." ;
		Block2 = "No operation initialized..." ;
		Block3 = "No operation initialized..." ;
		Block4 = "No operation initialized..." ;
		Block5 = "No operation initialized..." ;

		m_Step1 = "Step I: No operation initialized...";
		m_Step2 = "Step II: No operation initialized...";
		m_Step3 = "Step III: No operation initialized...";
	}

	//Load Image ...
	if(WhichOperation == 1)
	{
		Block1 = "(1) The Original Image..." ;		

		m_Step1 = "Step I: Loading the Original Image...";		
		m_Step2 = "Step II: No operation in Step II...";
		m_Step3 = "Step III: No operation in Step III...";
	}

	//GrayScale the Original Image ...
	if(WhichOperation == 2)
	{
		Block2 = "(2) Grayscaling the Original Image..." ;		

		m_Step1 = "Step I: Grayscaling the Original Image...";
		m_Step2 = "Step II: No operation in Step II...";
		m_Step3 = "Step III: No operation in Step III...";
	}

	//Finding the Barcode Area ...
	if(WhichOperation == 3)
	{
		Block3 = "(3) Finding the Barcode Area..." ;		

		m_Step1 = "Step I: Thresholding the Grayscaled Image...";
		m_Step2 = "Step II: Differencing the Grayscaled Image and Step I...";
		m_Step3 = "Step III: Averaging the Grayscaled Image and Step II...";		
	}

	//Barcode Area Enhancement ...
	if(WhichOperation == 4)
	{
		Block4 = "(4) Barcode Area Enhancement..." ;		

		m_Step1 = "Step I: Loading Step III of the Previous Operation...";
		m_Step2 = "Step II: Histogram Equelizing of Step I...";
		m_Step3 = "Step III: Thresholding Step II...";		
	}

	//Barcode Decoding ...
	if(WhichOperation == 5)
	{
		Block5 = "(5) Barcode Decoding..." ;		

		m_Step1 = "Step I: Decoding the Barcode...";
		m_Step2 = "Step II: No operation in Step II...";
		m_Step3 = "Step III: No operation in Step III...";
	}
	
	Info = "Info: "; 
	Info = Info + "Please, move the mouse over the image or object to get an info ...";
	UpdateData(FALSE);
/*
	Block1 = "(1) The Original Image..." ;
	Block2 = "(2) Grayscaling the Original Image..." ;
	Block3 = "(3) Finding the Barcode Area..." ;
	Block4 = "(4) Barcode Area Enhancement..." ;
	Block5 = "(5) Barcode Decoding..." ;

	m_Step1 = "Step I: No operation initialized...";
	m_Step2 = "Step II: No operation initialized...";
	m_Step3 = "Step III: No operation initialized...";
*/
}


void CBarcode1Dlg::ClearSteps()
{
	CClientDC dc(this);
	m_ImgEdit1.ClearDisplay();
	
	//Clearing the Charts 1, 2 & 3...
	for(i=0 ; i<16 ; i++)
		ColorDepth[i] = 0 ;

	ChartInit(1);
	ChartInit(2);
	ChartInit(3);

	m_Chart1.SetTitleText("No Data \"Image\" in Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("No Data \"Image\" in Step II");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("No Data \"Image\" in Step III");	
	m_Chart3.Refresh();
	
	//Clearing Step I, II and III ...
	for(i=209 ; i<426 ; i++ )
	{
		for(j=25 ; j<289 ; j++)
		{
			dc.SetPixelV(j,i,RGB(255,255,255));
			dc.SetPixelV(j+290,i,RGB(255,255,255));
			dc.SetPixelV(j+580,i,RGB(255,255,255));
		}
	}	
}


void CBarcode1Dlg::ResizeImage(int Where2Draw)
{
	//To Resize Large Images...
	CClientDC dc(this);
	int OKI=0,OKJ;
	bool DrawCol,DrawRow=1;

	I=0;

	// OnConvert2GS() ...
	if(Where2Draw == 0)		
	{
		fptr1=fopen("c:\\barcode\\gsofimage.txt","r");
		fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
				
		for(i=20 ; i<ImgHieght+20 ; i++)
		{
			DrawCol=1; OKJ=0; J=0;
			for(j=220 ; j<ImgWidth+220 ; j++)
			{
				fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				
				if( DrawCol && DrawRow )
					dc.SetPixelV(j-J,i-I,RGB(rgbr,rgbg,rgbb));

				OKJ++;
				if(OKJ >= 2)
				{	
					if(DrawCol == 0)	{	DrawCol=1;	OKJ=0;	J++;	}
					
					else	DrawCol=0;					
				}
			}

			OKI++;
			if(OKI >= 2)
			{	
				if(DrawRow == 0)	{	DrawRow=1;	OKI=0;	I++;	}
				
				else	DrawRow=0;					
			}
		}
		
		//DrawHistogram(1);
		goto Finish;
	}


	// OnamjbFilter1() ...
	if(Where2Draw == 1)		
	{
		fptr1=fopen("c:\\barcode\\bcarea.txt","r");  // amjbf1s3
		fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
				
		for(i=20 ; i<bcy2-bcy1+20 ; i++)
		{
			DrawCol=1; OKJ=0; J=0;
			for(j=420 ; j<bcx2-bcx1+420 ; j++)
			{
				fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				
				if( DrawCol && DrawRow )
					dc.SetPixelV(j-J,i-I,RGB(rgbr,rgbg,rgbb));

				OKJ++;
				if(OKJ >= 2)
				{	
					if(DrawCol == 0)	{	DrawCol=1;	OKJ=0;	J++;	}
					
					else	DrawCol=0;					
				}
			}

			OKI++;
			if(OKI >= 2)
			{	
				if(DrawRow == 0)	{	DrawRow=1;	OKI=0;	I++;	}
				
				else	DrawRow=0;					
			}
		}

		//DrawHistogram(2);
		goto Finish;
	}


	// OnamjbFilter2() ...
	if(Where2Draw == 2)		
	{
		fptr1=fopen("c:\\barcode\\amjbf2s3.txt","r");
		fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
				
		for(i=20 ; i<bcy2-bcy1+20 ; i++)
		{
			DrawCol=1; OKJ=0; J=0;
			for(j=620 ; j<bcx2-bcx1+620 ; j++)
			{
				fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				
				if( DrawCol && DrawRow )
					dc.SetPixelV(j-J,i-I,RGB(rgbr,rgbg,rgbb));

				OKJ++;
				if(OKJ >= 2)
				{	
					if(DrawCol == 0)	{	DrawCol=1;	OKJ=0;	J++;	}
					
					else	DrawCol=0;					
				}
			}

			OKI++;
			if(OKI >= 2)
			{	
				if(DrawRow == 0)	{	DrawRow=1;	OKI=0;	I++;	}
				
				else	DrawRow=0;					
			}
		}

		//DrawHistogram(3);
		goto Finish;
	}

	// OnBCDecode() ...
	if(Where2Draw == 3)     
	{
		fptr1=fopen("c:\\barcode\\bcdecode.txt","r");
		fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
				
		for(i=20 ; i<bcy2-bcy1+20 ; i++)
		{
			DrawCol=1; OKJ=0; J=0;
			for(j=820 ; j<bcx2-bcx1+820 ; j++)
			{
				fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				
				if( DrawCol && DrawRow )
					dc.SetPixelV(j-J,i-I,RGB(rgbr,rgbg,rgbb));

				OKJ++;
				if(OKJ >= 2)
				{	
					if(DrawCol == 0)	{	DrawCol=1;	OKJ=0;	J++;	}
					
					else	DrawCol=0;					
				}
			}

			OKI++;
			if(OKI >= 2)
			{	
				if(DrawRow == 0)	{	DrawRow=1;	OKI=0;	I++;	}
				
				else	DrawRow=0;					
			}
		}

		//DrawHistogram(4);
		goto Finish;
	}

Finish:	_fcloseall();
}


void CBarcode1Dlg::DrawHistogram(int WhichOperation)
{
	CClientDC dc(this);

	//Clearing all the Charts first ...
	for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;

	ChartInit(1);
	ChartInit(2);
	ChartInit(3);
	
	//For Original Image Histograms ...
	if(WhichOperation == 0)
	{
		/*fptr1=fopen("c:\\barcode\\originalimage.txt","r");
		fscanf(fptr1,"\n");*/

		//For rgbr ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				//fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);

				FindColorDepth(rgbr);				
			}
		}
		ChartInit(1);
		
		//For rgbg ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbg= GetGValue(rgb);
				
				FindColorDepth(rgbg);				
			}
		}		
		ChartInit(2);

		//For rgbb ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbb= GetBValue(rgb);
				
				FindColorDepth(rgbb);				
			}
		}	
		ChartInit(3);

		goto histo;
	}
	

	//For GrayScaled Image Histogram ...
	if(WhichOperation == 1)
	{		
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(1);

		goto histo;
	}


	//For amjbFilter1 Histogram ...
	if(WhichOperation == 2)
	{		
		//For Step I ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(1);

		//For Step II ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=316 ; j<ImgWidth+314 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(2);

		//For Step III ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=606 ; j<ImgWidth+604 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(3);

		goto histo;
	}


	//For amjbFilter2 Histogram ...
	if(WhichOperation == 3)
	{		
		//For Step I ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<bcy2-bcy1+209 ; i++)
		{
			for(j=26 ; j<bcx2-bcx1+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(1);

		//For Step II ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<bcy2-bcy1+209 ; i++)
		{
			for(j=316 ; j<bcx2-bcx1+314 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(2);

		//For Step III ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=606 ; j<ImgWidth+604 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(3);

		goto histo;
	}


	//For Barcode Decoding Histogram ...
	if(WhichOperation == 4)
	{		
		//For Step I ...
		for(i=0 ; i<16 ; i++)
			ColorDepth[i] = 0 ;
		
		for(i=211 ; i<ImgHieght+209 ; i++)
		{
			for(j=26 ; j<ImgWidth+24 ; j++)
			{
				rgb = dc.GetPixel(j,i);
				rgbr= GetRValue(rgb);
				
				FindColorDepth(rgbr);				
			}
		}		
		ChartInit(1);
	}

histo: rgbr = rgbr ;
	   //_fcloseall();
}


void CBarcode1Dlg::FindColorDepth(int WhichColor)
{
	rgb1 = RGB(WhichColor,WhichColor,WhichColor);

	//To Find the GSImage Depth...
	if(rgb1 <= RGB(16,16,16))
	{
		ColorDepth[0]++; goto okfound;
	}

	if(rgb1 <= RGB(32,32,32))         //0 is OK for Both Images (Ideal! & Captured) ...
	{
		ColorDepth[1]++; goto okfound;
	}

	if(rgb1 <= RGB(48,48,48))         //0 is OK for Both Images (Ideal! & Captured) ...
	{
		ColorDepth[2]++; goto okfound;
	}

	if(rgb1 <= RGB(64,64,64))         //0 is OK for Both Images (Ideal! & Captured) ...
	{
		ColorDepth[3]++; goto okfound;
	}
			
	if(rgb1 <= RGB(80,80,80))         //0 is OK for Both Images (Ideal! & Captured) ...
	{
		ColorDepth[4]++; goto okfound;
	}
			
	if(rgb1 <= RGB(96,96,96))         //0 is OK for Both Images (Ideal! & Captured) ...
	{
		ColorDepth[5]++; goto okfound;
	}
			
	if(rgb1 <= RGB(112,112,112))
	{
		ColorDepth[6]++; goto okfound;
	}
	
	if(rgb1 <= RGB(128,128,128))
	{
		ColorDepth[7]++; goto okfound;
	}
			
	if(rgb1 <= RGB(144,144,144))
	{
		ColorDepth[8]++; goto okfound;
	}

	if(rgb1 <= RGB(160,160,160))
	{
		ColorDepth[9]++; goto okfound;
	}
			
	if(rgb1 <= RGB(176,176,176))
	{
		ColorDepth[10]++; goto okfound;
	}
			
	if(rgb1 <= RGB(192,192,192))
	{
		ColorDepth[11]++; goto okfound;
	}

	if(rgb1 <= RGB(208,208,208))
	{
		ColorDepth[12]++; goto okfound;
	}
	
	if(rgb1 <= RGB(224,224,224))
	{
		ColorDepth[13]++; goto okfound;
	}
		
	if(rgb1 <= RGB(240,240,240))
	{
		ColorDepth[14]++; goto okfound;
	}

	if(rgb1 <= RGB(255,255,255))
	{
		ColorDepth[15]++; goto okfound;			  
	}

okfound:	rgbr = rgbr ;
}


void CBarcode1Dlg::ChartInit(int WhichChart)
{
	//Clearing the m_Chart1, 2 and 3 ...	
	COleSafeArray saRet/*1,saRet2,saRet3*/;
	SAFEARRAYBOUND sab[2];

	sab[0].cElements =16;  // 16 Rows x 2 Columns...
	sab[1].cElements =2;

	sab[0].lLbound = sab[1].lLbound = 1;

	saRet.Create(VT_BSTR, 2, sab);

	// Initialize them with values...
	int Label=0,temp=16;
	long index[2] = { 0, 0 };   //a 2D graph needs a 2D array as index array
	double val = 0;
	BSTR bstr;
	CString cstr;

	//The New One is HERE !!! ...
	index[0] = 1;        //The First Row ...
	for (i = 0 ; i<16 ; i++)
	{
		index[1] = 1;    //Column for Label ...				
		cstr.Format("  %d ",Label);
		if(i == 0)		Label += temp ;
		Label += 16 ;		
		bstr = cstr.AllocSysString();
		saRet.PutElement(index, bstr);

		index[1] = 2;    //Column for Data ...
		cstr.Format("%d",ColorDepth[i]);
		bstr = cstr.AllocSysString();
		::SysFreeString(bstr);
	    saRet.PutElement(index, bstr);

		index[0]++;      //The Next Row ...
	}

	// Return the safe-array encapsulated in a VARIANT...	
	if(WhichChart == 1)		m_Chart1.SetChartData(saRet.Detach());
	if(WhichChart == 2)		m_Chart2.SetChartData(saRet.Detach());
	if(WhichChart == 3)		m_Chart3.SetChartData(saRet.Detach());
}


void CBarcode1Dlg::OnLoadImage() 
{
	// TODO: Add your control notification handler code here

	CClientDC dc(this);
	//NewButton = false ;

	GetDlgItem(IDC_BLOCK1)->EnableWindow(TRUE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);

	ClearSteps();
	//ShowInfo(1);
	CheckInfo = 0 ;		//For the Three Steps ...
	Not2Draw=0;			//To init. the ResizeImage() ...

	m_ImgEdit1.ClearDisplay();
/*
	fptr3=fopen("c:\\barcode\\status.txt","r");
	fscanf(fptr3,"%s",status);
*/
	//For the Image Capturing by the Webcam ...
	//
	if( status == "Capturing")
	{
		fptr1=fopen("c:\\barcode\\originalimage.txt","w");
		fptr2=fopen("c:\\barcode\\captureimage.txt","r");
		fscanf(fptr2,"\n");              //Don't forget this before reading and writing...
		fprintf(fptr1,"\n");

		for(i=210 ; i<425 ; i++)
		{
			for(j=25 ; j<288 ; j++)
			{
				fscanf(fptr2,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
				dc.SetPixelV(j,i,RGB(rgbr,rgbg,rgbb));
			}
		}

		//To Save the Original Image in the "originalimage.txt"...
		for(i=210 ; i<425 ; i++)
		{
			for(j=25 ; j<288 ; j++)
			{
				rgb=dc.GetPixel(j,i);

				rgbr=GetRValue(rgb);
				rgbg=GetGValue(rgb);
				rgbb=GetBValue(rgb);

				fprintf(fptr1,"%d %d %d\n",rgbr,rgbg,rgbb);
			}
		}
		fprintf(fptr1,"\nImage Width = %d , Image Hieght = % d\n",ImgWidth,ImgHieght);
		//_fcloseall(); ImgWidth+25 ImgHieght+210
		ImgHieght = 425 - 210 ;
		ImgWidth = 288 - 25 ;
	}
	//
	//End of the Image Capturing by the Webcam ...


	//For the No Image Capturing by the Webcam ...
	//
	if( status == "No_Capturing")
	{

	if( NewButton == false )
	{

	//Init. & load an image...
	//m_ImgEdit1.ClearDisplay();
	m_ImgEdit2.ClearDisplay();
	this->Invalidate(TRUE); 	

	//CClientDC dc(this);
	
	fptr1=fopen("c:\\barcode\\originalimage.txt","w");
	
	m_ImgAdmin1.SetImage("");
	m_ImgAdmin1.SetDialogTitle("Select an Image...");
	m_ImgAdmin1.SetCancelError(FALSE);
	
	m_ImgAdmin1.SetFilter("All Image Files (*.bmp;*.jpg)|*.bmp; *.jpg|Bitmap Files    (*.bmp)|*.bmp|JPEG Files      (*.jpg)|*.jpg|All Files           (*.*)|*.*|");
	m_ImgAdmin1.SetFilterIndex(1);

	/*
	All Image Files (*.bmp;*.jpg)
	Bitmap Files    (*.bmp)
	JPEG Files      (*.jpg)
	All Files       (*.*)
	*/

	VARIANT vhWnd; V_VT(&vhWnd) =  VT_I4;
    V_I4(&vhWnd) = (long)m_hWnd;
	m_ImgAdmin1.ShowFileDialog(0,vhWnd);

	if(m_ImgAdmin1.GetImage() == "")
		return ;

	ImagePathName = m_ImgAdmin1.GetImage();
	m_ImgEdit1.SetImage(m_ImgAdmin1.GetImage());
	m_ImgEdit2.SetImage(m_ImgAdmin1.GetImage());

	VARIANT evt; V_VT(&evt) = VT_ERROR;
	m_ImgEdit1.FitTo(0,evt);
	m_ImgEdit2.FitTo(0,evt);

	m_ImgEdit2.Display();

	//Start of the Tick's Timer...
	Tick01.Start();
	//
	m_ImgEdit1.Display();
	
	ShowInfo(1);

	//Find the Width and Hieght...
	//Find the Width...
	for(i=220 ; i<425 ; i++)
	{
		for(j=288 ; j>25 ; j--)
		{
			rgb=dc.GetPixel(j,i);
			rgb1=dc.GetPixel(j-1,i);
			if(rgb-rgb1)
			{
				ImgWidth=j;
				goto okw;
			}
			dc.SetPixelV(j,i,RGB(255,0,0));
		}
	}

okw:ImgWidth -= 25;

	//Find the Hieght...
	for(i=35 ; i<288 ; i++)
	{
		for(j=425 ; j>210 ; j--)
		{
			rgb=dc.GetPixel(i,j);
			rgb1=dc.GetPixel(i,j-1);
			if(rgb-rgb1)
			{
				ImgHieght=j;
				goto okh;
			}
			dc.SetPixelV(i,j,RGB(255,0,0));
		}
	}

okh:ImgHieght -= 210;
//okh:ImgHieght = ImgWidth;

	fprintf(fptr1,"\n");              //Don't forget this before reading and writing...
	//To Save the Original Image in the "originalimage.txt"...
	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			rgb=dc.GetPixel(j,i);

			rgbr=GetRValue(rgb);
			rgbg=GetGValue(rgb);
			rgbb=GetBValue(rgb);

			fprintf(fptr1,"%d %d %d\n",rgbr,rgbg,rgbb);
		}
	}

	fprintf(fptr1,"\nImage Width = %d , Image Hieght = % d\n",ImgWidth,ImgHieght);
	
	//_fcloseall();
	
	}	

	if(NewButton == true)
	{
		m_ImgAdmin1.SetImage("");
		m_ImgEdit1.SetImage(ImagePathName);
		m_ImgEdit1.Display();
	}
	
	}
	//
	//End of the No Image Capturing by the Webcam ...


	DrawHistogram(0);

	m_Chart1.SetTitleText("Red Channel Histogram of Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("Green Channel Histogram of Step I");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("Blue Channel Histogram of Step I");	
	m_Chart3.Refresh();
	
	
	Tick01.Stop();
	ticks=Tick01.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","w");
	fprintf(fptr_ticks,"\n (1)  The Loading Time = %f\n",ticks);
	_fcloseall();

	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CONVERT2GS)->EnableWindow(TRUE);
/*	GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);*/
	GetDlgItem(IDC_DRAW)->EnableWindow(TRUE);

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_CONVERT2GS);
	GotoDlgCtrl(GetFocus);

	NewButton = true ;	
}


void CBarcode1Dlg::OnConvert2GS() 
{
	// TODO: Add your control notification handler code here

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(TRUE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);

	ClearSteps();
	ShowInfo(2);
	CheckInfo = 1 ;		//For the Three Steps ...

	CClientDC dc(this);

	fptr1=fopen("c:\\barcode\\originalimage.txt","r");
	fptr2=fopen("c:\\barcode\\gsofimage.txt","w");
	

	//Start of the Tick's Timer...
	Tick02.Start();
	//

	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fprintf(fptr2,"\n");
	//To Read the Original Image from the "originalimage.txt"...
	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);

			//GrayScale = 0.299*R + 0.587*G + 0.144*B ;
			rgb = RGB(rgbr,rgbg,rgbb);

			//To Convert the Original Image to GSImage...			
			if(rgb <= RGB(16,16,16))
			{
				rgbr=0; goto okgs;
			}

			if(rgb <= RGB(32,32,32))         //0 is OK for Both Images (Ideal! & Captured) ...
			{
				rgbr=32; goto okgs;
			}

			if(rgb <= RGB(48,48,48))         //0 is OK for Both Images (Ideal! & Captured) ...
			{
				rgbr=48; goto okgs;
			}

			if(rgb <= RGB(64,64,64))         //0 is OK for Both Images (Ideal! & Captured) ...
			{
				rgbr=64; goto okgs;
			}
			
			if(rgb <= RGB(80,80,80))         //0 is OK for Both Images (Ideal! & Captured) ...
			{
				rgbr=80; goto okgs;
			}
			
			if(rgb <= RGB(96,96,96))         //0 is OK for Both Images (Ideal! & Captured) ...
			{
				rgbr=96; goto okgs;
			}
			
			if(rgb <= RGB(112,112,112))
			{
				rgbr=112; goto okgs;
			}
			
			if(rgb <= RGB(128,128,128))
			{
				rgbr=128; goto okgs;
			}
			
			if(rgb <= RGB(144,144,144))
			{
				rgbr=144; goto okgs;
			}

			if(rgb <= RGB(160,160,160))
			{
				rgbr=160; goto okgs;
			}
			
			if(rgb <= RGB(176,176,176))
			{
				rgbr=176; goto okgs;
			}
			
			if(rgb <= RGB(192,192,192))
			{
				rgbr=192; goto okgs;
			}

			if(rgb <= RGB(208,208,208))
			{
				rgbr=208; goto okgs;
			}
			
			if(rgb <= RGB(224,224,224))
			{
				rgbr=224; goto okgs;
			}
			
			if(rgb <= RGB(240,240,240))
			{
				rgbr=240; goto okgs;
			}

			if(rgb <= RGB(255,255,255))
			{
				rgbr=255; goto okgs;			  
			}

okgs:      	dc.SetPixelV(j,i,RGB(rgbr,rgbr,rgbr));

			fprintf(fptr2,"%d %d %d\n",rgbr,rgbr,rgbr);			
		}
	}
	
	//_fcloseall();


//	if(Not2Draw == 0)	{	ResizeImage(0);		Not2Draw++;		}

	DrawHistogram(1);

	m_Chart1.SetTitleText("Grayscale Histogram of Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("No Data \"Image\" in Step II");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("No Data \"Image\" in Step III");	
	m_Chart3.Refresh();


	Tick02.Stop();
	ticks=Tick02.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n (2)  The Converting 2 GS Time = %f\n",ticks);
	_fcloseall();

	if(Not2Draw == 0)	{	ResizeImage(0);		Not2Draw++;		}

	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	//GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(TRUE);
/*	GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);
	GetDlgItem(IDC_DRAW)->EnableWindow(FALSE);	*/

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_AMJBFILTER1);
	GotoDlgCtrl(GetFocus);
}


void CBarcode1Dlg::OnamjbFilter1() 
{
	// TODO: Add your control notification handler code here	

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(TRUE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);

	ClearSteps();
	ShowInfo(3);
	CheckInfo = 2 ;		//For the Three Steps ...

	CClientDC dc(this);	
	int x11,y11,x12,y12,x21,y21,x22,y22;
	RECT m_rect={10,10,50,50};
	CRect m_crect;
	CBrush m_brush;

	fptr1=fopen("c:\\barcode\\gsofimage.txt","r");
	fptr2=fopen("c:\\barcode\\amjbf1s1.txt","w");
	fptr3=fopen("c:\\barcode\\amjbf1s2.txt","w");
	fptr4=fopen("c:\\barcode\\amjbf1s3.txt","w");
	fptr5=fopen("c:\\barcode\\bcarea.txt","w");
	
	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fprintf(fptr2,"\n");
	fprintf(fptr3,"\n");
	fprintf(fptr4,"\n");
	fprintf(fptr5,"\n");


	//Start of the Tick's Timer...
	Tick03_ALL.Start();
	//

	//To Draw the three Steps...
	//
	//Step i... Drawing the Threshold...
	Tick03_1.Start();

	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			rgb = RGB(rgbr,rgbg,rgbb);
			//dc.SetPixelV(i,j,RGB(255,0,0));

			//To Draw the Threshold...    (Step I)
			if(rgb >= RGB(128,128,128))        //240 is OK for Both Images (Ideal! & Captured) ...
			{
				//rgb1=RGB(255,255,255);
				dc.SetPixelV(j,i,RGB(255,255,255));
				fprintf(fptr2,"255 255 255\n");
			}
			else
			{
				//rgb1=RGB(0,0,0);
				dc.SetPixelV(j,i,RGB(0,0,0));
				fprintf(fptr2,"0 0 0\n");
			}
		}
	}
	fclose(fptr1);

	Tick03_1.Stop();
	ticks=Tick03_1.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n (3)  The BC Area Finding Time :");
	fprintf(fptr_ticks,"\n      The BC Area Finding Time - Step i = %f",ticks);
//	fclose(fptr_ticks);


	//Step ii... Drawing the Difference...
	Tick03_2.Start();
	fptr1=fopen("c:\\barcode\\gsofimage.txt","r");
	fscanf(fptr1,"\n");
	
	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			rgb1 = dc.GetPixel(j,i);
			//rgb = RGB(rgbr,rgbg,rgbb);
			
			//rgbr = GetRValue(rgb);
			rgbg = GetGValue(rgb1);
			rgbb = abs(rgbr-rgbg);

			rgb2 = RGB(rgbb,rgbb,rgbb);
			dc.SetPixelV(j+290,i,RGB(rgbb,rgbb,rgbb));
			//rgbr = GetRValue(rgb2);
			fprintf(fptr3,"%d %d %d\n",rgbb,rgbb,rgbb);
		}
	}
	fclose(fptr1);

	Tick03_2.Stop();
	ticks=Tick03_2.Elapsed();
//	FILE *fptr_ticks;
//	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
//	fprintf(fptr_ticks,"\n (3)  The BC Area Finding Time :\n");
	fprintf(fptr_ticks,"\n      The BC Area Finding Time - Step ii = %f",ticks);
//	fclose(fptr_ticks);


	//Step iii... Drawing the Averaging...
	Tick03_3.Start();
	fptr1=fopen("c:\\barcode\\gsofimage.txt","r");
	fscanf(fptr1,"\n");

	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			rgb2 = dc.GetPixel(j+290,i);
			//rgb = RGB(rgbr,rgbg,rgbb);

			//rgbr = GetRValue(rgb);
			rgbg = GetGValue(rgb2);
			rgbb = int((rgbr+rgbg)/2);

			rgb3 = RGB(rgbb,rgbb,rgbb);
			if(rgb3 >= RGB(127,127,127))
			{
				dc.SetPixelV(j+580,i,RGB(255,255,0));
				fprintf(fptr4,"255 255 0\n");
			}
			
			else
			{
				//rgbb = GetBValue(rgb3);				
				dc.SetPixelV(j+580,i,RGB(rgbb,rgbb,rgbb));
				fprintf(fptr4,"%d %d %d\n",rgbb,rgbb,rgbb);
			}
		}
	}

/*	//To Draw the three Steps...
	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=25 ; j<ImgWidth+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			rgb = RGB(rgbr,rgbg,rgbb);
			//dc.SetPixelV(i,j,RGB(255,0,0));

			//To Draw the Threshold...    (Step I)
			if(rgb >= RGB(128,128,128))        //240 is OK for Both Images (Ideal! & Captured) ...
			{
				rgb1=RGB(255,255,255);
				dc.SetPixelV(j,i,RGB(255,255,255));
				fprintf(fptr2,"255 255 255\n");
			}
			else
			{
				rgb1=RGB(0,0,0);
				dc.SetPixelV(j,i,RGB(0,0,0));
				fprintf(fptr2,"0 0 0\n");
			}

			//To Draw the Difference...   (Step II)
			rgbr = GetRValue(rgb);
			rgbg = GetGValue(rgb1);
			rgbb = abs(rgbr-rgbg);

			rgb2 = RGB(rgbb,rgbb,rgbb);
			dc.SetPixelV(j+290,i,RGB(rgbb,rgbb,rgbb));
			//rgbr = GetRValue(rgb2);
			fprintf(fptr3,"%d %d %d\n",rgbb,rgbb,rgbb);
			
			//To Draw the Averaging...    (Step III)
			rgbr = GetRValue(rgb);
			rgbg = GetGValue(rgb2);
			rgbb = int((rgbr+rgbg)/2);

			rgb3 = RGB(rgbb,rgbb,rgbb);
			if(rgb3 >= RGB(127,127,127))
			{
				dc.SetPixelV(j+580,i,RGB(255,255,0));
				fprintf(fptr4,"255 255 0\n");
			}
			
			else
			{
				//rgbb = GetBValue(rgb3);				
				dc.SetPixelV(j+580,i,RGB(rgbb,rgbb,rgbb));
				fprintf(fptr4,"%d %d %d\n",rgbb,rgbb,rgbb);
			}
		}
	}

	Tick03_1.Stop();
	ticks=Tick03_1.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n (3)  The amjbFilter1 Time :\n");
	fprintf(fptr_ticks,"\n      The Avg. Time of Step i, ii and iii = %f\n",ticks);
	fclose(fptr_ticks);
*/
	//To Draw the Clipping Region...(Red Rect.) on the (x11,y11) , (x12,y12) , (x21,y21) & (x22,y22)
	// --\ ... ( j++ , i ) == ( x11 , y11 )
	// --/
	J = 605 + int(ImgWidth/4);
	for(i=210 ; i<ImgHieght+210 ; i++)
	{
		for(j=605 ; j<J ; j++)  // ImgWidth+605
		{			
			rgb = dc.GetPixel(j  ,i  );
			rgb1= dc.GetPixel(j-1,i-1);
			rgb2= dc.GetPixel(j+1,i-1);
			rgb3= dc.GetPixel(j-1,i+1);
			rgb4= dc.GetPixel(j+1,i+1);

			//dc.SetPixelV(j,i,RGB(0,255,0));
			if( rgb == RGB(255,255,0) && rgb1 == RGB(255,255,0) && rgb2 == RGB(255,255,0) &&
				rgb3 == RGB(255,255,0) && rgb4 == RGB(255,255,0) )
			{				
				//m_rect.left=j;
				x11=j;
				//m_rect.top=i;
				y11=i;
				goto NEXT11;
			}
		}
	}
NEXT11:

	// || ... ( j , i++ ) == ( x12 , y12 )
	// \/
	I = 210 + int(ImgHieght/4);
	for(j=605 ; j<ImgWidth+605 ; j++)
	{
		for(i=210 ; i<I ; i++)   // ImgHieght+210
		{			
			rgb = dc.GetPixel(j  ,i  );
			rgb1= dc.GetPixel(j-1,i-1);
			rgb2= dc.GetPixel(j+1,i-1);
			rgb3= dc.GetPixel(j-1,i+1);
			rgb4= dc.GetPixel(j+1,i+1);

			//dc.SetPixelV(j,i,RGB(0,255,0));
			if( rgb == RGB(255,255,0) && rgb1 == RGB(255,255,0) && rgb2 == RGB(255,255,0) &&
				rgb3 == RGB(255,255,0) && rgb4 == RGB(255,255,0) )
			{				
				//m_rect.left=j;
				x12=j;
				//m_rect.top=i;
				y12=i;
				goto NEXT12;
			}
		}
	}
NEXT12:

	// /-- ... ( j-- , i ) == ( x21 , y21 )
	// \--
	J = ImgWidth - int(ImgWidth/4);
	for(i=ImgHieght+209 ; i>210 ; i--)
	{
		for(j=ImgWidth+604 ; j>J+605 ; j--)  
		{			
			rgb = dc.GetPixel(j  ,i  );
			rgb1= dc.GetPixel(j-1,i-1);
			rgb2= dc.GetPixel(j+1,i-1);
			rgb3= dc.GetPixel(j-1,i+1);
			rgb4= dc.GetPixel(j+1,i+1);

			//dc.SetPixelV(j,i,RGB(0,255,0));
			if( rgb == RGB(255,255,0) && rgb1 == RGB(255,255,0) && rgb2 == RGB(255,255,0) &&
				rgb3 == RGB(255,255,0) && rgb4 == RGB(255,255,0) )
			{				
				//m_rect.left=j;
				x21=j;
				//m_rect.top=i;
				y21=i;
				goto NEXT21;
			}
		}
	}
NEXT21:

	// /\ ... ( j , i-- ) == ( x22 , y22 )
	// ||
	I = ImgHieght - int(ImgHieght/4);
	for(j=ImgWidth+604 ; j>605 ; j--)
	{
		for(i=ImgHieght+209 ; i>I+210 ; i--)
		{			
			rgb = dc.GetPixel(j  ,i  );
			rgb1= dc.GetPixel(j-1,i-1);
			rgb2= dc.GetPixel(j+1,i-1);
			rgb3= dc.GetPixel(j-1,i+1);
			rgb4= dc.GetPixel(j+1,i+1);

			//dc.SetPixelV(j,i,RGB(0,255,0));
			if( rgb == RGB(255,255,0) && rgb1 == RGB(255,255,0) && rgb2 == RGB(255,255,0) &&
				rgb3 == RGB(255,255,0) && rgb4 == RGB(255,255,0) )
			{				
				//m_rect.left=j;
				x22=j;
				//m_rect.top=i;
				y22=i;
				goto NEXT22;
			}
		}
	}
NEXT22:	
	
	m_rect.left=x12;
	m_rect.top=y11;
	m_rect.right=x22;
	m_rect.bottom=y21;

	m_brush.CreateSolidBrush(RGB(255,0,0));
	m_crect.CopyRect(&m_rect);
	dc.FrameRect(&m_crect,&m_brush);
	
	m_brush.Detach();   //The Important One...

	//Saving the Barcode Area ... (from the Red Rect.)
	bcx1 = x12 ;
	bcy1 = y11 ;
	bcx2 = x22 ;
	bcy2 = y21 ;

	for(i=bcy1 ; i<bcy2 ; i++)
	{
		for(j=bcx1 ; j<bcx2 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			rgbr = GetRValue(rgb);
			rgbg = GetGValue(rgb);
			rgbb = GetBValue(rgb);
			fprintf(fptr5,"%d %d %d\n",rgbr,rgbg,rgbb);
		}
	}


	//To Find the Barcode Area... (Blue Rect.) on the (x12,y11) & (x22,y21)
	I = y11 + ((y21-y11)/3);
	for(j=x12+2 ; j<x22 ; j++)
	{
		for(i=y11+2 ; i<I ; i++)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb != 0x0000ffff)         //RGB(255,255,0) 
			{				
				m_rect.left=j;
				//bcx1=j;
				m_rect.top=i;
				//bcy1=i;
				goto FINISH1;
			}
		}
	}
FINISH1:
	
	I = y21 - ((y21-y11)/3);
	for(j=x22-2 ; j>x12 ; j--)
	{		
		for(i=y21-2 ; i>I ; i--)
		{			
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(0,255,0));
			if(rgb != 0x0000ffff)
			{				
				m_rect.right=j+4;
				//bcx2=j+4;
				m_rect.bottom=i+4;
				//bcy2=i+4;
				goto FINISH2;
			}
		}
	}
FINISH2:
	
	m_brush.CreateSolidBrush(RGB(0,0,255));
	m_crect.CopyRect(&m_rect);
	dc.FrameRect(&m_crect,&m_brush);

	m_brush.Detach();   //The Important One...

	//_fcloseall();
	
	Tick03_3.Stop();
	ticks=Tick03_3.Elapsed();
//	FILE *fptr_ticks;
//	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
//	fprintf(fptr_ticks,"\n (3)  The BC Area Finding Time :\n");
	fprintf(fptr_ticks,"\n      The BC Area Finding Time - Step iii = %f\n",ticks);
	fclose(fptr_ticks);

//	if(Not2Draw == 1)	{	ResizeImage(1);		Not2Draw++;		}

	DrawHistogram(2);

	m_Chart1.SetTitleText("GrayScale Histogram of Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("GrayScale Histogram of Step II");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("GrayScale Histogram of Step III");	
	m_Chart3.Refresh();


	Tick03_ALL.Stop();
	ticks=Tick03_ALL.Elapsed();
//	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n      The BC Area Finding Total Time = %f\n",ticks);
	_fcloseall();

	if(Not2Draw == 1)	{	ResizeImage(1);		Not2Draw++;		}

	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	//GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	//GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(TRUE);
	//GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);
	//GetDlgItem(IDC_DRAW)->EnableWindow(FALSE);

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_AMJBFILTER2);
	GotoDlgCtrl(GetFocus);
}


void CBarcode1Dlg::OnamjbFilter2() 
{
	// TODO: Add your control notification handler code here	

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(TRUE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);

	ClearSteps();
	ShowInfo(4);
	CheckInfo = 3 ;		//For the Three Steps ...

	CClientDC dc(this);
	int N,Nk[16];
	float Pr[16],S[16];

	fptr1=fopen("c:\\barcode\\bcarea.txt","r");  //amjb Filter2 Step1...
	fptr2=fopen("c:\\barcode\\amjbf2s2.txt","w");
	fptr3=fopen("c:\\barcode\\amjbf2s3.txt","w");


	//Clearing all the varaibles...
	for(i=0 ; i<16 ; i++)
	{
		Nk[i]   = 0  ;
		Pr[i]   = 0.0;
		S[i]    = 0.0;
	}

	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fprintf(fptr2,"\n");
	fprintf(fptr3,"\n");

	
	//Start of the Tick's Timer...
	Tick04_ALL.Start();
	//

	//To Draw the Clipping Region & Barcode Area...
	Tick04_1.Start();

	I=bcy2-bcy1;
	J=bcx2-bcx1;
	for(i=210 ; i<I+210 ; i++)
	{
		for(j=25 ; j<J+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			rgb = RGB(rgbr,rgbg,rgbb);
			
			if( rgb == RGB(255,0,0) || rgb == RGB(255,255,0) || rgb == RGB(0,0,255) )
				dc.SetPixelV(j,i,RGB(255,255,255));

			else
				dc.SetPixelV(j,i,RGB(rgbr,rgbg,rgbb));
		}
	}

	Tick04_1.Stop();
	ticks=Tick04_1.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n (4)  The BC Area Enhance Time :");
	fprintf(fptr_ticks,"\n      The BC Area Enhance - Step i = %f",ticks);
//	fclose(fptr_ticks);

	
	//To Take info from the Barcode Area... (from Step I to Step II)
	Tick04_2.Start();

	for(i=210 ; i<I+210 ; i++)
	{		
		for(j=25 ; j<J+25 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(255,0,0));			
			
			if(rgb == RGB(0,0,0))
			{
				Nk[0]++;	goto okq;
			}

			if(rgb == RGB(32,32,32))
			{
				Nk[1]++;	goto okq;
			}

			if(rgb == RGB(48,48,48))
			{
				Nk[2]++;	goto okq;
			}

			if(rgb == RGB(64,64,64))
			{
				Nk[3]++;	goto okq;
			}
			
			if(rgb == RGB(80,80,80))
			{
				Nk[4]++;	goto okq;
			}
			
			if(rgb == RGB(96,96,96))
			{
				Nk[5]++;	goto okq;
			}
			
			if(rgb == RGB(112,112,112))
			{
				Nk[6]++;	goto okq;
			}
			
			if(rgb == RGB(128,128,128))
			{
				Nk[7]++;	goto okq;
			}
			
			if(rgb == RGB(144,144,144))
			{
				Nk[8]++;	goto okq;
			}

			if(rgb == RGB(160,160,160))
			{
				Nk[9]++;	goto okq;
			}
			
			if(rgb == RGB(176,176,176))
			{
				Nk[10]++;	goto okq;
			}
			
			if(rgb == RGB(192,192,192))
			{
				Nk[11]++;	goto okq;
			}

			if(rgb == RGB(208,208,208))
			{
				Nk[12]++;	goto okq;
			}
			
			if(rgb == RGB(224,224,224))
			{
				Nk[13]++;	goto okq;
			}
			
			if(rgb == RGB(240,240,240))
			{
				Nk[14]++;	goto okq;
			}

			if(rgb == RGB(255,255,255))
			{
				Nk[15]++;	goto okq;
			}

okq:     rgbr = rgbr ; //To Continue...   
		}
	}


	N = I * J;  // # of pixels...	

	for(i=0 ; i<16 ; i++)
		Pr[i]=(float)Nk[i] / (float)N;

	for(i= 0 ; i<16 ; i++)
	{
		for(j=0 ; j<(i+1) ; j++)
			S[i] +=  Pr[j];
	}

	for(i=0 ; i<16 ; i++)
		S[i] *= 255.0;


	//To Draw the Equalized Histogram...
	for(i=0 ; i<16 ; i++)
		Nk[i] = (int)S[i];

	for(i=210 ; i<I+210 ; i++)
	{
		for(j=25 ; j<J+25 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i,RGB(255,0,0));
			

			if(rgb == RGB(  0,  0,  0))
			{
				rgb=Nk[0]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB( 32, 32, 32))
			{
				rgb=Nk[1]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB( 48, 48, 48))
			{
				rgb=Nk[2]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB( 64, 64, 64))
			{
				rgb=Nk[3]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB( 80, 80, 80))
			{
				rgb=Nk[4]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB( 96, 96, 96))
			{
				rgb=Nk[5]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(112,112,112))
			{
				rgb=Nk[6]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(128,128,128))
			{
				rgb=Nk[7]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(144,144,144))
			{
				rgb=Nk[8]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(160,160,160))
			{
				rgb=Nk[9]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(176,176,176))
			{
				rgb=Nk[10]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(192,192,192))
			{
				rgb=Nk[11]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(208,208,208))
			{
				rgb=Nk[12]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(224,224,224))
			{
				rgb=Nk[13]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(240,240,240))
			{
				rgb=Nk[14]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

			if(rgb == RGB(255,255,255))
			{
				rgb=Nk[15]; dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));
				goto okh;
			}

okh:        fprintf(fptr2,"%d %d %d\n",rgb,rgb,rgb);
		}
	}	

	Tick04_2.Stop();
	ticks=Tick04_2.Elapsed();
//	FILE *fptr_ticks;
//	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n      The BC Area Enhance - Step ii = %f",ticks);
//	fclose(fptr_ticks);


	//To Draw the Threshold...
	Tick04_3.Start();

	for(i=210 ; i<I+210 ; i++)
	{
		for(j=315 ; j<J+315 ; j++)
		{
			rgb=dc.GetPixel(j,i);
			//dc.SetPixelV(j,i+198,RGB(255,0,0));

			if(rgb < RGB(112,112,112))
				rgb=0;
			else
				rgb=255;

			dc.SetPixelV(j+290,i,RGB(rgb,rgb,rgb));

			fprintf(fptr3,"%d %d %d\n",rgb,rgb,rgb);
		}
	}

	//_fcloseall();

	Tick04_3.Stop();
	ticks=Tick04_3.Elapsed();
//	FILE *fptr_ticks;
//	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n      The BC Area Enhance - Step iii = %f\n",ticks);
	fclose(fptr_ticks);

//	if(Not2Draw == 2)	{	ResizeImage(2);		Not2Draw++;		}

	DrawHistogram(3);

	m_Chart1.SetTitleText("GrayScale Histogram of Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("GrayScale Histogram of Step II");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("GrayScale Histogram of Step III");	
	m_Chart3.Refresh();


	Tick04_ALL.Stop();
	ticks=Tick04_ALL.Elapsed();
//	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n      The BC Area Enhance Total Time = %f\n",ticks);
	_fcloseall();

	if(Not2Draw == 2)	{	ResizeImage(2);		Not2Draw++;		}

	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	//GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	//GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	//GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(TRUE);
	GetDlgItem(IDC_BCDECODE)->EnableWindow(TRUE);
	//GetDlgItem(IDC_DRAW)->EnableWindow(FALSE);

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_BCDECODE);
	GotoDlgCtrl(GetFocus);
}


void CBarcode1Dlg::OnBCDecode() 
{
	// TODO: Add your control notification handler code here	

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(TRUE);

	ClearSteps();
	ShowInfo(5);
	CheckInfo = 4 ;		//For the Three Steps ...

	CClientDC dc(this);
	
	int count,k,BAR,SPACE,barcode[13];
	float BarcodeData[59],BarcodeBlock[12],cfloat,barw,spacew;
	char bar_space;
	CString Direction,DirL2R,BARCODE[13],BarcodeType,BARCODETYPE[6];
		
	fptr1=fopen("c:\\barcode\\amjbf2s3.txt","r");
	fptr2=fopen("c:\\barcode\\test.3.txt","w");
	fptr3=fopen("c:\\barcode\\test.35.txt","w");
	fptr4=fopen("c:\\barcode\\test.4.txt","w");
	fptr5=fopen("c:\\barcode\\test.45.txt","w");
	fptr6=fopen("c:\\barcode\\test.5.txt","w");
	fptr7=fopen("c:\\barcode\\test.55.txt","w");
	fptr8=fopen("c:\\barcode\\test.6.txt","w");
	fptr9=fopen("c:\\barcode\\test.65.txt","w");
	fptr10=fopen("c:\\barcode\\test.7.txt","w");
	

	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fprintf(fptr2,"\n");
	fprintf(fptr3,"\n");
	fprintf(fptr4,"\n");
	fprintf(fptr5,"\n");
	fprintf(fptr6,"\n");
	fprintf(fptr7,"\n");
	fprintf(fptr8,"\n");
	fprintf(fptr9,"\n");
	fprintf(fptr10,"\n");
//	fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
//	fprintf(fptr2,"%d %d %d\n",rgb,rgb,rgb);

	for(i=0 ; i<59 ; i++)
		BarcodeData[i] = 2.0 ;

/*
	bcx1 = 0 ;
	bcy1 = 0 ;
	bcx2 = J ;
	bcy2 = I ;
*/
	//Start of the Tick's Timer...
	Tick05.Start();
	//
	//To Draw the Barcode Area ...
	for(i=210 ; i<bcy2-bcy1+210 ; i++)
	{
		for(j=25 ; j<bcx2-bcx1+25 ; j++)
		{
			fscanf(fptr1,"%d %d %d\n",&rgbr,&rgbg,&rgbb);
			/*rgbr += 1 ;
			rgbg += 1 ;
			rgbb += 1 ;*/
			dc.SetPixelV(j,i,RGB(rgbr,rgbg,rgbb));
		}
	}	

	//To Scan from Multiple Positions in the Barcode Area ...
	for(cfloat=3.0 ; cfloat<7.5 ; cfloat += 0.5)
	{
		I = (int)( 210 + ( (bcy2-bcy1) * cfloat * 0.1 ) ); 
		BAR = -1;
		SPACE = -1;
		count = 0;    //Counter how many digits store in the file...
		rgb1 = 0x00000000;
		//J=0;
		k = 0;
		bar_space = '!';
		for(j=27 ; j<bcx2-bcx1+25 ; j++)            //width...
		{
			rgb=dc.GetPixel(j,I);

			//if(rgb <= RGB(127,127,127) && BAR == -1)	goto check;

			if(rgb > RGB(127,127,127) && SPACE == -1)
				BAR=0;
			
			if(rgb <= RGB(127,127,127) && BAR >= 0)
			{
				BAR++;
				SPACE=0;
				
				dc.SetPixelV(j,I,RGB(0,0,255));
			}
					
			if(rgb > RGB(127,127,127) && SPACE >= 0)
			{
				SPACE++;
				BAR=0;
				
				dc.SetPixelV(j,I,RGB(255,0,0));
			}

			if(rgb < RGB(128,128,128))	rgb = RGB(0,0,0);			
		
			if(rgb >= RGB(128,128,128))	rgb = RGB(255,255,255);
		
			if(rgb1 != rgb)
			{				
				if(cfloat == 3.0) fprintf(fptr2,"\n %d %c",k,bar_space);
				if(cfloat == 3.5) fprintf(fptr3,"\n %d %c",k,bar_space);
				if(cfloat == 4.0) fprintf(fptr4,"\n %d %c",k,bar_space);
				if(cfloat == 4.5) fprintf(fptr5,"\n %d %c",k,bar_space);
				if(cfloat == 5.0) fprintf(fptr6,"\n %d %c",k,bar_space);
				if(cfloat == 5.5) fprintf(fptr7,"\n %d %c",k,bar_space);
				if(cfloat == 6.0) fprintf(fptr8,"\n %d %c",k,bar_space);
				if(cfloat == 6.5) fprintf(fptr9,"\n %d %c",k,bar_space);
				if(cfloat == 7.0) fprintf(fptr10,"\n %d %c",k,bar_space);
				
				count++;
			}
		
			if(BAR)
			{
				k=BAR;
				bar_space='b';
			}
			else
			{
				k=SPACE;
				bar_space='w';
			}

			rgb1=rgb;
			//dc.SetPixelV(j,check2,RGB(255,0,0));
		}
	}

	//fprintf(fptr6,"\n count = %d ",count);   //test.7.txt

	_fcloseall();
	
	cfloat = 0.0 ;

	fptr1=fopen("c:\\barcode\\test.3.txt","r");
	fptr2=fopen("c:\\barcode\\test.35.txt","r");
	fptr3=fopen("c:\\barcode\\test.4.txt","r");
	fptr4=fopen("c:\\barcode\\test.45.txt","r");
	fptr5=fopen("c:\\barcode\\test.5.txt","r");
	fptr6=fopen("c:\\barcode\\test.55.txt","r");
	fptr7=fopen("c:\\barcode\\test.6.txt","r");
	fptr8=fopen("c:\\barcode\\test.65.txt","r");
	fptr9=fopen("c:\\barcode\\test.7.txt","r");
	fptr10=fopen("c:\\barcode\\testavg.txt","w");
			

	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fscanf(fptr2,"\n");
	fscanf(fptr3,"\n");
	fscanf(fptr4,"\n");
	fscanf(fptr5,"\n");
	fscanf(fptr6,"\n");
	fscanf(fptr7,"\n");
	fscanf(fptr8,"\n");
	fscanf(fptr9,"\n");
	fprintf(fptr10,"\n");
	//fprintf(fptr2,"\n %d %c",k,bar_space);

	//To get the Average ...
	for(i=0 ; i<count ; i++)
	{
		J=0;

		fscanf(fptr1,"\n %d %c",&I,&bar_space); J  = I;
		fscanf(fptr2,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr3,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr4,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr5,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr6,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr7,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr8,"\n %d %c",&I,&bar_space); J += I;
		fscanf(fptr9,"\n %d %c",&I,&bar_space); J += I;

		J = int (floor( ((float)J/9.0) + 0.5 ) );
		fprintf(fptr10,"\n %d %c",J,bar_space);
	}

	_fcloseall();	

	fptr1=fopen("c:\\barcode\\testavg.txt","r");
	fptr2=fopen("c:\\barcode\\barcode.txt","w");
	fptr3=fopen("c:\\barcode\\bcdecode.txt","w");

	fscanf(fptr1,"\n");              //Don't forget this before reading and writing...
	fprintf(fptr2,"\n ");
	fprintf(fptr3,"\n ");

	//Store the testavg.txt in the Array "BarcodeData[59]"...
	J=0;
	for(i=0 ; i<count ; i++)
	{
		fscanf(fptr1,"\n %d %c",&I,&bar_space);
		if(I > 0 && J <59)
		{
			BarcodeData[J] = (float)I; 			
			fprintf(fptr2," BarcodeData[%d]= %f\n",J,BarcodeData[J]);
			J++;
		}
	}

	//fprintf(fptr2,"\n");
	//Save & Test the BarcodeData[59] into a File ...
/*	for(i=0 ; i<59 ; i++)
		fprintf(fptr2," BarcodeData[%d]= %f\n",i,BarcodeData[i]);
*/

	//To get the Divider for all in the BarcodeData[59]...
/*	cfloat =(float)( (BarcodeData[0 ] + BarcodeData[1 ] + BarcodeData[2 ] 
		  + BarcodeData[27]+ BarcodeData[28] + BarcodeData[29] + BarcodeData[30] + BarcodeData[31]
		  + BarcodeData[56] + BarcodeData[57] + BarcodeData[58]) / 11.0 );
*/
	barw = float((  BarcodeData[0 ] + BarcodeData[2 ] + BarcodeData[28] + BarcodeData[30] + BarcodeData[56] + BarcodeData[58]) / 6.0 );
	
	spacew = float((BarcodeData[1 ] + BarcodeData[27] + BarcodeData[29] + BarcodeData[31] + BarcodeData[57]) / 5.0 );

	fprintf(fptr2,"\n\n barwidth = %f & spacewidth = %f\n\n",barw,spacew);

	//if(check > 1)
	//{
		for(i=0 ; i<59 ; i+=2)
		{
			BarcodeData[i] /= barw;     // cfloat ... barw .....   
			j = i + 1 ;
			BarcodeData[j] /= spacew;   // cfloat ... spacew ...
			
			BarcodeData[i] += 0.5;
			BarcodeData[i] = (float)(floor(BarcodeData[i]));

			BarcodeData[j] += 0.5;
			BarcodeData[j] = (float)(floor(BarcodeData[j]));

			if(BarcodeData[i] == 0.0)
				BarcodeData[i]=1.5;

			if(BarcodeData[j] == 0.0)
				BarcodeData[j]=1.5;

			fprintf(fptr2," BarcodeData[%d]= %f\n",i,BarcodeData[i]);
			if(j < 59)
				fprintf(fptr2," BarcodeData[%d]= %f\n",j,BarcodeData[j]);
		}
	//}

	fprintf(fptr2,"\n ");
	//Store the BarcodeData[] in the BarcodeBlock[]...
	//The Left-Hand Side Barcode...
	j=0;
	for(i=3 ; i<27 ; i+=4)
	{
		BarcodeData[i  ] *= 2000.0;
		BarcodeData[i+1] *= 200.0;
		BarcodeData[i+2] *= 20.0;
		BarcodeData[i+3] *= 2.0;
	
		BarcodeBlock[j] = BarcodeData[i  ] + BarcodeData[i+1] + 
			              BarcodeData[i+2] + BarcodeData[i+3];
		
		fprintf(fptr2," BarcodeBlock[%d] = %d\n",j,(int)BarcodeBlock[j]);
		j++;
	}

	//The Right-Hand Side Barcode...
	j=6;
	for(i=32 ; i<56 ; i+=4)
	{
		BarcodeData[i  ] *= 2000.0;
		BarcodeData[i+1] *= 200.0;
		BarcodeData[i+2] *= 20.0;
		BarcodeData[i+3] *= 2.0;
	
		BarcodeBlock[j] = BarcodeData[i  ] + BarcodeData[i+1] + 
			              BarcodeData[i+2] + BarcodeData[i+3];
		
		fprintf(fptr2," BarcodeBlock[%d] = %d\n",j,(int)BarcodeBlock[j]);
		j++;
	}	

//	fcloseall();

	//BarcodeLookupTable()

	//BOOL BARCODETYPE[12];
	//CClientDC dc(this);	
/*	FILE *fptr1,*fptr2;
		
	fptr1=fopen("c:\\BarCode\\Barcode.txt","r");
	fptr2=fopen("c:\\BarCode\\test.txt","w");
*/
	Direction = "Left" ;
	DirL2R = "OK" ;
	j=0;

	fprintf(fptr2,"\n");
	//Clearing the BARCODE[]...
	for(i=0 ; i<13 ;i++)
	{
		BARCODE[i]="?";
		fprintf(fptr2," BARCODE[%d]= %s\n",i,BARCODE[i]);
	}

	//Checking the Direction of Scanning ... ( from Left 2 Right ) ...
	I = int(BarcodeBlock[0]);
	//if(DirL2R == "NotOK")
	{
		//MessageBox("The Test of checking the Direction is OK","DirL2R OK()",MB_OK);
		if( I > 7322 && I <= 8300 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 6:Even ...
		if( I > 6233 && I <= 6332 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 8:Even ...
		if( I > 4532 && I <= 5423 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 4:Even ...
		if( I > 4343 && I <= 4433 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 2:Even ...
		if( I > 4253 && I <= 4343 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 7:Even ...
		if( I > 3524 && I <= 4235 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 9:Even ...
		if( I > 2633 && I <= 2732 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 5:Even ...
		if( I > 2435 && I <= 2453 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 1:Even ...
		if( I > 2273 && I <= 2354 )		{ DirL2R = "NotOK" ; goto chk_Dir ; }	// 3:Even ...
		if( I > 2237 && I <= 2255 )		{ DirL2R = "NotOK" ; goto chk_Dir ; } 	// 0:Even ...
	}
	

	//From L2R Scan ...
chk_Dir:
	if(DirL2R == "OK")
	{
	//L-R Decoding...	
	for(i=0 ; i<12 ; i++)
	{
		j=i+1;
		I = int(BarcodeBlock[i]);  
		//fscanf(fptr1," %d\n",&check);
		//fprintf(fptr2," %d\n",check);
		
		
		//Left-Hand Decoding...
		if( I > 8000 && Direction == "Left") /* 7500 */  { barcode[j]=0; BARCODE[j]="X"; BARCODETYPE[i]="1";}

		if( I > 7322 && I <= 8000 && Direction == "Left"){ barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="1";}
		if( I > 6332 && I <= 7322 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="0";}
		if( I > 6233 && I <= 6332 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="1";}
		if( I > 5423 && I <= 6233 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="0";}
		if( I > 4532 && I <= 5423 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="1";}
		if( I > 4433 && I <= 4532 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="0";}
		if( I > 4343 && I <= 4433 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="1";}
		if( I > 4253 && I <= 4343 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="1";}
		if( I > 4235 && I <= 4253 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="0";}
		if( I > 3524 && I <= 4235 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="1";}
		if( I > 2732 && I <= 3524 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="0";}
		if( I > 2633 && I <= 2732 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="1";}
		if( I > 2543 && I <= 2633 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="0";}
		if( I > 2453 && I <= 2543 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="0";}
		if( I > 2435 && I <= 2453 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="1";}
		if( I > 2354 && I <= 2435 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="0";}
		if( I > 2273 && I <= 2354 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="1";}
		if( I > 2255 && I <= 2273 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="0";}
		if( I > 2237 && I <= 2255 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="1";}
		if( I > 2137 && I <= 2237 && Direction == "Left"){ barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="0";}

		if( I <= 2137 && Direction == "Left")            { barcode[j]=0; BARCODE[j]="X"; BARCODETYPE[i]="0";}
		

		//Right-Hand Decoding...
		if( I > 6430 && Direction == "Right")              { barcode[j]=0; BARCODE[j]="X";}

		if( I > 6323 && I <= 6430 && Direction == "Right") { barcode[j]=0; BARCODE[j]="0";}
		if( I > 5333 && I <= 6323 && Direction == "Right") { barcode[j]=9; BARCODE[j]="9";}
		if( I > 4343 && I <= 5333 && Direction == "Right") { barcode[j]=1; BARCODE[j]="1";}
		if( I > 3533 && I <= 4343 && Direction == "Right") { barcode[j]=2; BARCODE[j]="2";}
		if( I > 2723 && I <= 3533 && Direction == "Right") { barcode[j]=3; BARCODE[j]="3";}
		if( I > 2543 && I <= 2723 && Direction == "Right") { barcode[j]=7; BARCODE[j]="7";}
		if( I > 2444 && I <= 2543 && Direction == "Right") { barcode[j]=5; BARCODE[j]="5";}
		if( I > 2345 && I <= 2444 && Direction == "Right") { barcode[j]=8; BARCODE[j]="8";}
		if( I > 2246 && I <= 2345 && Direction == "Right") { barcode[j]=4; BARCODE[j]="4";}
		if( I > 2150 && I <= 2246 && Direction == "Right") { barcode[j]=6; BARCODE[j]="6";}

		if( I <= 2150 && Direction == "Right")             { barcode[j]=0; BARCODE[j]="X";}
		
		if(i >= 6)  Direction="Right";
	}
	}
	
		
	//From R2L Scan ...
	if(DirL2R == "NotOK")
	{
		MessageBox("The Test of checking the Direction is OK","DirL2R = NotOK",MB_OK);
		j = 0 ;
		J = 11 ;
		Direction = "Left" ;

	//L-R Decoding...	
	for(i=0 ; i<12 ; i++)
	{
		j=i+1;
		I = int(BarcodeBlock[J]);  
		//fscanf(fptr1," %d\n",&check);
		//fprintf(fptr2," %d\n",check);

		//Normalizing the Numbers ...
		//Left Normalization ...		

		//Right Normalization ...		
		
		//Left-Hand Decoding...
		if( I > 8300 && Direction == "Left")  /* 7500 */ { barcode[j]=0; BARCODE[j]="X"; BARCODETYPE[i]="0";}

		if( I > 7322 && I <= 8300 && Direction == "Left"){ barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="0";}
		if( I > 6332 && I <= 7322 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="1";}
		if( I > 6233 && I <= 6332 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="0";}
		if( I > 5423 && I <= 6233 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="1";}
		if( I > 4532 && I <= 5423 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="0";}
		if( I > 4433 && I <= 4532 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="1";}
		if( I > 4343 && I <= 4433 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="0";}
		if( I > 4253 && I <= 4343 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="0";}
		if( I > 4235 && I <= 4253 && Direction == "Left"){ barcode[j]=2; BARCODE[j]="2"; BARCODETYPE[i]="1";}
		if( I > 3524 && I <= 4235 && Direction == "Left"){ barcode[j]=9; BARCODE[j]="9"; BARCODETYPE[i]="0";}
		if( I > 2732 && I <= 3524 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="1";}
		if( I > 2633 && I <= 2732 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="0";}
		if( I > 2543 && I <= 2633 && Direction == "Left"){ barcode[j]=7; BARCODE[j]="7"; BARCODETYPE[i]="1";}
		if( I > 2453 && I <= 2543 && Direction == "Left"){ barcode[j]=5; BARCODE[j]="5"; BARCODETYPE[i]="1";}
		if( I > 2435 && I <= 2453 && Direction == "Left"){ barcode[j]=1; BARCODE[j]="1"; BARCODETYPE[i]="0";}
		if( I > 2354 && I <= 2435 && Direction == "Left"){ barcode[j]=8; BARCODE[j]="8"; BARCODETYPE[i]="1";}
		if( I > 2273 && I <= 2354 && Direction == "Left"){ barcode[j]=3; BARCODE[j]="3"; BARCODETYPE[i]="0";}
		if( I > 2255 && I <= 2273 && Direction == "Left"){ barcode[j]=4; BARCODE[j]="4"; BARCODETYPE[i]="1";}
		if( I > 2237 && I <= 2255 && Direction == "Left"){ barcode[j]=0; BARCODE[j]="0"; BARCODETYPE[i]="0";}
		if( I > 2137 && I <= 2237 && Direction == "Left"){ barcode[j]=6; BARCODE[j]="6"; BARCODETYPE[i]="1";}

		if( I <= 2137 && Direction == "Left")            { barcode[j]=0; BARCODE[j]="X"; BARCODETYPE[i]="1";}
		

		//Right-Hand Decoding...
		if( I > 8300 && Direction == "Right")              { barcode[j]=0; BARCODE[j]="X";}

		if( I > 7232 && I <= 8300 && Direction == "Right") { barcode[j]=6; BARCODE[j]="6";}
		if( I > 5432 && I <= 7232 && Direction == "Right") { barcode[j]=8; BARCODE[j]="8";}
		if( I > 4523 && I <= 5432 && Direction == "Right") { barcode[j]=4; BARCODE[j]="4";}
		if( I > 4343 && I <= 4523 && Direction == "Right") { barcode[j]=2; BARCODE[j]="2";}
		if( I > 4244 && I <= 4343 && Direction == "Right") { barcode[j]=7; BARCODE[j]="7";}
		if( I > 3434 && I <= 4244 && Direction == "Right") { barcode[j]=9; BARCODE[j]="9";}
		if( I > 2543 && I <= 3434 && Direction == "Right") { barcode[j]=5; BARCODE[j]="5";}
		if( I > 2363 && I <= 2543 && Direction == "Right") { barcode[j]=1; BARCODE[j]="1";}
		if( I > 2264 && I <= 2363 && Direction == "Right") { barcode[j]=3; BARCODE[j]="3";}
		if( I > 2226 && I <= 2264 && Direction == "Right") { barcode[j]=0; BARCODE[j]="0";}

		if( I <= 2226 && Direction == "Right")             { barcode[j]=0; BARCODE[j]="X";}
		
		if(i >= 6)  Direction="Right";

		J-- ;
	}
	}


	//Find the System Digit...
	BarcodeType = BARCODETYPE[0] + BARCODETYPE[1] + BARCODETYPE[2] +
		          BARCODETYPE[3] + BARCODETYPE[4] + BARCODETYPE[5] ;

	fprintf(fptr2,"\n BarcodeType = %s\n",BarcodeType);

	if(BarcodeType == "000000") BARCODE[0]="0";
	if(BarcodeType == "001011") BARCODE[0]="1";
	if(BarcodeType == "001101") BARCODE[0]="2";
	if(BarcodeType == "001110") BARCODE[0]="3";
	if(BarcodeType == "010011") BARCODE[0]="4";
	if(BarcodeType == "011001") BARCODE[0]="5";
	if(BarcodeType == "011100") BARCODE[0]="6";
	if(BarcodeType == "010101") BARCODE[0]="7";
	if(BarcodeType == "010110") BARCODE[0]="8";
	if(BarcodeType == "011010") BARCODE[0]="9";
	else                        BARCODE[0]="X";

	fprintf(fptr2,"\n");
	//Printing the Result...
	fprintf(fptr2," BARCODE[0]= %s\n",BARCODE[0]);
	for(i=1 ; i<13 ; i++)
	{
		j=i-1;
		if(i <= 6)
			fprintf(fptr2," BARCODE[%d]= %s\tBARCODETYPE[%d]= %s\n",i,BARCODE[i],j,BARCODETYPE[j]);
		else
			fprintf(fptr2," BARCODE[%d]= %s\n",i,BARCODE[i]);
	}

	BarcodeType=" "+BARCODE[0]+" "+BARCODE[1]+BARCODE[2]+BARCODE[3]+BARCODE[4]+BARCODE[5]+BARCODE[6]+
		        " "+BARCODE[7]+BARCODE[8]+BARCODE[9]+BARCODE[10]+BARCODE[11]+BARCODE[12]+" ";


	fprintf(fptr2,"\n the Final Barcode = %s\n",BarcodeType);

	//To Draw the "amjb here..."...
/*	x3 = x1 + ((x2-x1)/3);
	y3 = y1 + ((y2-y1)/2);	
	dc.ExtTextOut(25,450,ETO_CLIPPED,m_crect,BarcodeType,12,NULL);*/

	J= int( (bcx2-bcx1) / 2 ) - 28;
	I= 200 + int( (bcy2-bcy1) / 2 );
	dc.TextOut(J,I,BarcodeType);

	//To Save the Final Decoded Image ...
	for(i=210 ; i<bcy2-bcy1+210 ; i++)
	{
		for(j=25 ; j<bcx2-bcx1+25 ; j++)
		{
			rgb  = dc.GetPixel(j,i);
			rgbr = GetRValue(rgb); 
			rgbg = GetGValue(rgb); 
			rgbb = GetBValue(rgb); 

			fprintf(fptr3,"%d %d %d\n",rgbr,rgbg,rgbb);			
		}
	}	

	//_fcloseall();

//	if(Not2Draw == 3)	{	ResizeImage(3);		Not2Draw++;		}

	DrawHistogram(4);

	m_Chart1.SetTitleText("GrayScale Histogram of Step I");	
	m_Chart1.Refresh();

	m_Chart2.SetTitleText("No Data \"Image\" in Step II");	
	m_Chart2.Refresh();

	m_Chart3.SetTitleText("No Data \"Image\" in Step III");	
	m_Chart3.Refresh();


	Tick05.Stop();
	ticks=Tick05.Elapsed();
	FILE *fptr_ticks;
	fptr_ticks=fopen("c:\\barcode\\__ticks.txt","a");
	fprintf(fptr_ticks,"\n (5)  The BC Area Decoding Time = %f\n",ticks);
	_fcloseall();


	if(Not2Draw == 3)	{	ResizeImage(3);		Not2Draw++;		}

	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	//GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	//GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	//GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(TRUE);
	//GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);
	//GetDlgItem(IDC_DRAW)->EnableWindow(TRUE);

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_DRAW);
	GotoDlgCtrl(GetFocus);
}


void CBarcode1Dlg::OnDraw()  //Test Button... 
{
	// TODO: Add your control notification handler code here

	GetDlgItem(IDC_BLOCK1)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK4)->EnableWindow(FALSE);
	GetDlgItem(IDC_BLOCK5)->EnableWindow(FALSE);

	ClearSteps();
	ShowInfo(0);

	status = "No_Capturing";

	m_ImgEdit1.ClearDisplay();
	m_ImgEdit2.ClearDisplay();
	this->Invalidate(TRUE);
		
	CheckInfo = -1 ;
	NewButton = false ;
	
/*	CClientDC dc(this);
	
	//For the Upper Five Blocks ...
	for(i=19 ; i<165 ; i++)
	{
		for(j=19 ; j<19+176 ; j++)
		{
			dc.SetPixelV(j,i,RGB(255,i,i));
			dc.SetPixelV(j+200,i,RGB(255,j,j));
			dc.SetPixelV(j+400,i,RGB(255,i,j));
			dc.SetPixelV(j+600,i,RGB(255,j,i));
			dc.SetPixelV(j+800,i,RGB(255,i,j));
		}
	}	

	//For the Three Steps ...
	for(i=210 ; i<425 ; i++)
	{
		for(j=25 ; j<25+263 ; j++)
		{
			dc.SetPixelV(j,i,RGB(i,255,i));
			dc.SetPixelV(j+290,i,RGB(j,255,j));
			dc.SetPixelV(j+580,i,RGB(i,255,j));			
		}
	}	

	//For the Three Histograms ...
	for(i=430 ; i<695 ; i++)
	{
		for(j=21 ; j<21+274 ; j++)
		{
			dc.SetPixelV(j,i,RGB(i,i,255));
			dc.SetPixelV(j+289,i,RGB(j,j,255));
			dc.SetPixelV(j+578,i,RGB(j,i,255));			
		}
	}	

	//For the Buttons ...
	for(i=368 ; i<368+26 ; i++)
	{
		for(j=909 ; j<986 ; j++)
		{
			dc.SetPixelV(j,i,RGB(255,0,0));
			dc.SetPixelV(j,i+47,RGB(255,0,0));
			dc.SetPixelV(j,i+94,RGB(255,0,0));
			dc.SetPixelV(j,i+141,RGB(255,0,0));
			dc.SetPixelV(j,i+188,RGB(255,0,0));
			dc.SetPixelV(j,i+235,RGB(255,0,0));
			dc.SetPixelV(j,i+282,RGB(255,0,0));			
		}
	}	
*/
	//GetDlgItem(IDC_LOADIMAGE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CONVERT2GS)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER1)->EnableWindow(FALSE);
	GetDlgItem(IDC_AMJBFILTER2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BCDECODE)->EnableWindow(FALSE);
	GetDlgItem(IDC_DRAW)->EnableWindow(FALSE);

	CButton* GetFocus;
	GetFocus = (CButton*) GetDlgItem(IDC_LOADIMAGE);
	GotoDlgCtrl(GetFocus);
}

void CBarcode1Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	//ClearSteps();
	//fclose(fptr_tick);	
	OnOK();
}

void CBarcode1Dlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	int xx,yy;
	POINT pt1;

	//For the Upper Five Blocks ...
	for(yy=19 ; yy<165 ; yy++)
	{
		for(xx=19 ; xx<19+176 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{	
				Info = "Info: The Original Image is displayed here ...";
				goto DispInfo1;
			}

			pt1.x = xx+200 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Grayscaled Image is displayed here ...";
				goto DispInfo1;				
			}

			pt1.x = xx+400 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Bracode Area is displayed here ...";
				goto DispInfo1;
			}

			pt1.x = xx+600 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Enhancement of Bracode Area is displayed here ...";
				goto DispInfo1;
			}

			pt1.x = xx+800 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Decoded Bracode is displayed here ...";
				goto DispInfo1;				
			}
		}
	}	

	//For the Three Steps ...
	for(yy=210 ; yy<425 ; yy++)
	{
		for(xx=25 ; xx<25+263 ; xx++)
		{
			//For Step I ...
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1 && CheckInfo == -1)
			{
				Info = "Step I: No Functionality here ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 0)
			{
				Info = "Step I: The Loaded Original Image ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 1)
			{
				Info = "Step I: Grayscaling of the Original Image \" 4-bit :: 16-GrayLevel \" ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 2)
			{
				Info = "Step I: Thresholding the Grayscaled Image \"at Color Depth =  128\" ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 3)
			{
				Info = "Step I: The Barocde Area ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 4)
			{
				Info = "Step I: The Decoded Barcode ...";
				goto DispInfo1;
			}

			//For Step II ...
			pt1.x = xx+290 ;
			pt1.y = yy ;
			if(point == pt1 && CheckInfo == -1)
			{
				Info = "Step II: No Functionality here ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 0)
			{
				Info = "Step II: No Functionality here ...";
				goto DispInfo1;
			}
			
			if(point == pt1 && CheckInfo == 1)
			{
				Info = "Step II: No Functionality here ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 2)
			{
				Info = "Step II: Differencing the Step I from the Grayscaled Image \" Step II = ABS ( Grayscale Image - Step I ) \" ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 3)
			{
				Info = "Step II: The Equalized Histogram of Step I ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 4)
			{
				Info = "Step II: No Functionality here ...";
				goto DispInfo1;
			}

			//For Step III ...
			pt1.x = xx+580 ;
			pt1.y = yy ;
			if(point == pt1 && CheckInfo == -1)
			{
				Info = "Step III: No Functionality here ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 0)
			{
				Info = "Step III: No Functionality here ...";
				goto DispInfo1;		
			}
			
			if(point == pt1 && CheckInfo == 1)
			{
				Info = "Step III: No Functionality here ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 2)
			{
				Info = "Step III: Averaging the Grayscaled Image with Step II \" Step III = (Grayscale Image + Step II)/2 \" ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 3)
			{
				Info = "Step III: Thresholding Step II \"at Color Depth = 112\" ...";
				goto DispInfo1;
			}

			if(point == pt1 && CheckInfo == 4)
			{
				Info = "Step III: No Functionality here ...";
				goto DispInfo1;
			}
		}
	}	
/*
	//For the Three Histograms ...
	for(yy=430 ; yy<695 ; yy++)
	{
		for(xx=21 ; xx<21+274 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo1;	
			}

			pt1.x = xx+289 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo1;	
			}

			pt1.x = xx+578 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo1;				
			}
		}
	}	
*/
/*
	//For the Buttons ...
	for(yy=368 ; yy<368+26 ; yy++)
	{
		for(xx=909 ; xx<986 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: Click to Load the Original Image ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+47 ;
			if(point == pt1)
			{
				Info = "Info: Click to Grayscale the Original Image ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+94 ;
			if(point == pt1)
			{
				Info = "Info: Click to Find the Barcode Area ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+141 ;
			if(point == pt1)
			{
				Info = "Info: Click to Enhance the Barcode Area ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+188 ;
			if(point == pt1)
			{
				Info = "Info: Click to Decode the Barcode ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+235 ;
			if(point == pt1)
			{
				Info = "Info: Click to Start New Session \"Load Original Image\" ...";
				goto DispInfo1;
			}

			pt1.x = xx ;
			pt1.y = yy+282 ;
			if(point == pt1)
			{
				Info = "Info: Click to Exit the Program ...";
				goto DispInfo1;			
			}
		}
	}
*/
DispInfo1: UpdateData(FALSE);

	CDialog::OnMouseMove(nFlags, point);
}

void CBarcode1Dlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
/*
	int xx,yy;
	POINT pt1;

	//For the Upper Five Blocks ...
	for(yy=19 ; yy<165 ; yy++)
	{
		for(xx=19 ; xx<19+176 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{	
				Info = "Info: The Original Image is displayed here ...";
				goto DispInfo2;
			}

			pt1.x = xx+200 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Grayscaled Image is displayed here ...";
				goto DispInfo2;				
			}

			pt1.x = xx+400 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Bracode Area is displayed here ...";
				goto DispInfo2;
			}

			pt1.x = xx+600 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Enhancement of Bracode Area is displayed here ...";
				goto DispInfo2;
			}

			pt1.x = xx+800 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Decoded Bracode is displayed here ...";
				goto DispInfo2;				
			}
		}
	}	

	//For the Three Steps ...
	for(yy=210 ; yy<425 ; yy++)
	{
		for(xx=25 ; xx<25+263 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Decoded Bracode is displayed here ...";
				goto DispInfo2;
			}

			pt1.x = xx+290 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Decoded Bracode is displayed here ...";
				goto DispInfo2;
			}

			pt1.x = xx+580 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Decoded Bracode is displayed here ...";
				goto DispInfo2;		
			}
		}
	}	

	//For the Three Histograms ...
	for(yy=430 ; yy<695 ; yy++)
	{
		for(xx=21 ; xx<21+274 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo2;	
			}

			pt1.x = xx+289 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo2;	
			}

			pt1.x = xx+578 ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: The Histogram ...";
				goto DispInfo2;				
			}
		}
	}	

	//For the Buttons ...
	for(yy=368 ; yy<368+26 ; yy++)
	{
		for(xx=909 ; xx<986 ; xx++)
		{
			pt1.x = xx ;
			pt1.y = yy ;
			if(point == pt1)
			{
				Info = "Info: Click to Load the Original Image ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+47 ;
			if(point == pt1)
			{
				Info = "Info: Click to Grayscale the Original Image ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+94 ;
			if(point == pt1)
			{
				Info = "Info: Click to Find the Barcode Area ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+141 ;
			if(point == pt1)
			{
				Info = "Info: Click to Enhance the Barcode Area ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+188 ;
			if(point == pt1)
			{
				Info = "Info: Click to Decode the Barcode ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+235 ;
			if(point == pt1)
			{
				Info = "Info: Click to Start New Session \"Load Original Image\" ...";
				goto DispInfo2;
			}

			pt1.x = xx ;
			pt1.y = yy+282 ;
			if(point == pt1)
			{
				Info = "Info: Click to Exit the Program ...";
				goto DispInfo2;			
			}
		}
	}

DispInfo2: UpdateData(FALSE);
*/	
	CDialog::OnRButtonDown(nFlags, point);
}

/*
void CBarcode1Dlg::OnAbc() 
{
	// TODO: Add your control notification handler code here
	CClientDC dc(this);

	for(i=210 ; i<425 ; i++)
	{
		for(j=25 ; j<288 ; j++)
		{
			dc.SetPixelV(j,i,RGB(255,0,0));
		}
	}	
}
*/