/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

// Barcode1Dlg.h : header file
//
//{{AFX_INCLUDES()
#include "imgadmin.h"
#include "imgedit.h"
#include "mschart.h"
//}}AFX_INCLUDES

#if !defined(AFX_BARCODE1DLG_H__3F81F745_BBDE_4F5C_961C_B52E196E1256__INCLUDED_)
#define AFX_BARCODE1DLG_H__3F81F745_BBDE_4F5C_961C_B52E196E1256__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PerfTimer.h"
/////////////////////////////////////////////////////////////////////////////
// CBarcode1Dlg dialog

class CBarcode1Dlg : public CDialog
{
// Construction
public:
	CBarcode1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CBarcode1Dlg)
	enum { IDD = IDD_BARCODE1_DIALOG };
	CImgEdit	m_ImgEdit1;
	CImgEdit    m_ImgEdit2;
	CImgAdmin	m_ImgAdmin1;	
	CString	m_Step1;
	CString	m_Step2;
	CString	m_Step3;
	CMSChart	m_Chart1;
	CMSChart	m_Chart2;
	CMSChart	m_Chart3;
	CString	Info;
	CString	Block1;
	CString	Block2;
	CString	Block3;
	CString	Block4;
	CString	Block5;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBarcode1Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	bool NewButton;
	int i,j,I,J,ImgWidth,ImgHieght,rgbr,rgbg,rgbb,bcx1,bcy1,bcx2,bcy2,Not2Draw,ColorDepth[16]
		,CheckInfo;
	double ticks;
	COLORREF rgb,rgb1,rgb2,rgb3,rgb4;	
	FILE *fptr1,*fptr2,*fptr3,*fptr4,*fptr5,*fptr6,*fptr7,*fptr8,*fptr9,*fptr10;
	CString ImagePathName,status;
	CPerfTimer Tick01,Tick02,Tick03_ALL,Tick03_1,Tick03_2,Tick03_3,Tick04_ALL,Tick04_1,Tick04_2,Tick04_3,Tick05;
			
	// Generated message map functions
	//{{AFX_MSG(CBarcode1Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();	
	afx_msg void OnLoadImage();
	afx_msg void OnConvert2GS();
	afx_msg void OnamjbFilter1();
	afx_msg void OnamjbFilter2();
	afx_msg void OnBCDecode();
	afx_msg void OnDraw();
	afx_msg void OnExit();	
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void ShowInfo(int WhichOperation);
	afx_msg void ClearSteps();
	afx_msg void ResizeImage(int Where2Draw);
	afx_msg void DrawHistogram(int WhichOperation);
	afx_msg void FindColorDepth(int WhichColor);
	afx_msg void ChartInit(int WhichChart);
//	afx_msg void OnAbc();
	//}}AFX_MSG
/*
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();	
	afx_msg void OnLoadImage();
	afx_msg void OnConvert2GS();
	afx_msg void OnamjbFilter1();
	afx_msg void OnamjbFilter2();
	afx_msg void OnBCDecode();
	afx_msg void OnDraw();
	afx_msg void OnExit();	
	
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

	afx_msg void ShowInfo(int WhichOperation);
	afx_msg void ClearSteps();
	afx_msg void ResizeImage(int Where2Draw);
	afx_msg void DrawHistogram(int WhichOperation);
	afx_msg void FindColorDepth(int WhichColor);
	afx_msg void ChartInit(int WhichChart);
*/
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BARCODE1DLG_H__3F81F745_BBDE_4F5C_961C_B52E196E1256__INCLUDED_)
