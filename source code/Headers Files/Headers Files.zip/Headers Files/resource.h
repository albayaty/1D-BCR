/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Barcode1.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BARCODE1_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_DRAW                        1000
#define IDC_EXIT                        1001
#define IDC_BCDECODE                    1002
#define IDC_AMJBFILTER2                 1003
#define IDC_AMJBFILTER1                 1004
#define IDC_CONVERT2GS                  1005
#define IDC_LOADIMAGE                   1006
#define IDC_STEP2                       1008
#define IDC_STEP3                       1009
#define IDC_STEP1                       1010
#define IDC_DESCRIPTION                 1012
#define IDC_INFO                        1012
#define IDC_IMGADMINCTRL1               1020
#define IDC_IMGEDITCTRL1                1021
#define IDC_RECSTEP1                    1022
#define IDC_RECSTEP2                    1023
#define IDC_RECSTEP3                    1024
#define IDC_IMGEDITCTRL2                1025
#define IDC_DARW0                       1026
#define IDC_DARW1                       1027
#define IDC_DARW2                       1028
#define IDC_DARW3                       1029
#define IDC_STEP1INFO                   1030
#define IDC_STEP2INFO                   1031
#define IDC_STEP3INFO                   1032
#define IDC_BLOCK1                      1033
#define IDC_BLOCK2                      1034
#define IDC_MSCHART1                    1035
#define IDC_MSCHART2                    1036
#define IDC_BLOCK3                      1037
#define IDC_BLOCK4                      1038
#define IDC_BLOCK5                      1039
#define IDC_ABOUT                       1040
#define IDC_ABC                         1041
#define IDC_MSCHART3                    1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
