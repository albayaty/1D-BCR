/* ==============================================
*  Copyright �  2014  Ali M. Al-Bayaty
*  
*  1D-BCR is free software: you can redistribute it and/or modify it
*  under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  any later version.
*  
*  1D-BCR is distributed in the hope that it will be useful, but
*  WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* ==============================================
*  
*  1D-BCR (1D BarCode Reader) Software Tool
*  
*  By: Ali M. Al-Bayaty
*  Personal Website: <http://albayaty.github.io/>
*
*  ==============================================
*/

// Barcode1.h : main header file for the BARCODE1 application
//

#if !defined(AFX_BARCODE1_H__B3AC31E1_C050_43A8_A695_9648905F1053__INCLUDED_)
#define AFX_BARCODE1_H__B3AC31E1_C050_43A8_A695_9648905F1053__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBarcode1App:
// See Barcode1.cpp for the implementation of this class
//

class CBarcode1App : public CWinApp
{
public:
	CBarcode1App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBarcode1App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBarcode1App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BARCODE1_H__B3AC31E1_C050_43A8_A695_9648905F1053__INCLUDED_)
